

$(function() {


  $( "#setCoinPeriod" ).click(function() {
    myModalInstance.show();
  });

  $( ".tt-menu" ).click(function() {
    myModalInstance.show();
  });


  $('form#typeahead').keydown(function(e) {
    if (e.which == 13) {
      myModalInstance.show();
    }});

  $( ".modal .jumbotron" ).click(function() {
    $(location).attr('href','type-program.html');
  });


// Snippets for showing and hiding the mega menu. And stuff doing things in the menu

  $("#expandCollapseButton").click(function(){
    $("#expandCollapseButton").text($("#expandCollapseButton").text() == 'Expand all' ? 'Collapse all' : 'Expand all');
  });

  $( ".jumbotron .dropdown-menu" ).click(function() {
    Cookies.set('coin-period', 'true');
    $(location).attr('href','browse-families.html');
  });

  $( ".close-menu").click(function() {
    $( "#mega-menu" ).slideUp( "5000", function() {
      // Animation complete.
    });
  });

// End snippets 

// Faking behaviour of a single page application  

  setTimeout(function(){
    $('html.scroll-to-hide, body').animate({
        scrollTop: $("body").offset().top + 85
    }, 300);
    $("html.scroll-to-hide c-navigation .dropdown").css("margin-right", "75px")
  }, 100);


  setTimeout(function(){
    $('html').css("display","none")
    $('html.hide-and-scroll, body').animate({
        scrollTop: $("body").offset().top + 85
    }, 10);
    $("html.hide-and-scroll c-navigation .dropdown").css("margin-right", "75px");
    $('html').css("display","block") 
  }, 100);

// End faking SPA 

// Faking full screen mode by hiding and showing some elements

  $( ".table caption i.fa-expand" ).click(function() {
    $( "c-header, c-footer, .container-fluid.mt-4" ).css("display","none");
    $( ".table caption i.fa-expand" ).addClass("hidden");
    $( ".table caption i.fa-compress" ).removeClass("hidden");
    $( ".table" ).addClass("mt-5");
    window.scrollTo(0, 0);
  });

  $( ".table caption i.fa-compress" ).click(function() {
    $( "c-header" ).css("display","flex");
    $( "c-footer, .container-fluid.mt-4" ).css("display","block");    
    $( ".table caption i.fa-compress" ).addClass("hidden");
    $( ".table caption i.fa-expand" ).removeClass("hidden");
    $( ".table" ).removeClass("mt-5");
  });  

// End faking

// Showing or hiding codes depending on user needs

  $( ".table th.code, table td.code, .table .code" ).css("display","none");

  $( ".table caption .codes-visibility" ).click(function() {
    $( ".table th.code, table td.code" ).css("display","table-cell");
    $( "table span.code" ).css("display","inline-block");
  });

// End showing or hiding codes

// Set some alerts clearifying that this is a prototype

  $( "#mega-menu ul li a[href='']" ).click(function() {
    event.preventDefault();
    alert('Currently this prototype can only work with the Cab Dimensions and Type Program choice.')
  });

  $( "a[href='']" ).click(function() {
    event.preventDefault();
    alert('Currently not available in this prototype.')
  }); 

// End alerts 


});  



// Create Modal for Selecting Coin

var myModal = document.getElementById('coin-selector-modal');

// initialize on a <div class="modal"> with all options
// Note: options object is optional
var myModalInstance = new Modal(myModal, 
{ // options object
  content: '<div class="jumbotron"> \
      <h1>No period selected</h1> \
      <p>You\'ll have to select a space in time.</p> \
      <div class="btn-group"> \ \
        <div class="btn-group"> \
          <button type="button" class="btn btn-transparent dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> \
            2019 <i class="fa fa-angle-down"></i> \
          </button> \
          <ul class="dropdown-menu"> \
            <li><a href="#">2019.04.1</a></li> \
            <li><a href="#">2019.06.1</a></li> \
            <li><a href="#">2019.09.1</a></li> \
            <li><a href="#">2019.11.3</a></li> \
          </ul> \
        </div> \
        <div class="btn-group"> \
          <button type="button" class="btn btn-transparent dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> \
            2020 <i class="fa fa-angle-down"></i> \
          </button> \
          <ul class="dropdown-menu"> \
            <li><a href="#">2020.04.1</a></li> \
            <li><a href="#">2020.06.1</a></li> \
            <li><a href="#">2020.09.1</a></li> \
            <li><a href="#">2020.11.3</a></li> \
          </ul> \
        </div> \
        <div class="btn-group"> \
          <button type="button" class="btn btn-transparent dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> \
            2021 <i class="fa fa-angle-down"></i> \
          </button> \
          <ul class="dropdown-menu"> \
            <li><a href="#">2021.04.1</a></li> \
            <li><a href="#">2021.06.1</a></li> \
            <li><a href="#">2021.09.1</a></li> \
            <li><a href="#">2021.11.3</a></li> \
          </ul> \
        </div> \
      </div> \
      <input type="text"  class="btn btn-transparent flatpickr-transparent" id="basicDate" placeholder="Custom Date" data-input> \
    </div> ', 
    // sets modal content
  backdrop: 'static', // we don't want to dismiss Modal when Modal or backdrop is the click event target
  keyboard: false // we don't want to dismiss Modal on pressing Esc key
});

// OR initialize and show the modal right away
var myModalInstance = new Modal(myModal);
// now you know why we don't need a show option



// Twitter Typeahead Code

$(document).ready(function() {

  // the basics
  // ----------

  var substringMatcher = function(strs) {
    return function findMatches(q, cb) {
      var matches, substringRegex;

      // an array that will be populated with substring matches
      matches = [];

      // regex used to determine if a string contains the substring `q`
      substrRegex = new RegExp(q, 'i');

      // iterate through the pool of strings and for any string that
      // contains the substring `q`, add it to the `matches` array
      $.each(strs, function(i, str) {
        if (substrRegex.test(str)) {
          matches.push(str);
        }
      });

      cb(matches);
    };
  };

  var states = ['Air In Outlet', 'Audio Signals', 'Axle Distance', 'Body Adaptation Box Body', 'Body Adaptation Tipper', 'Body Adaptation Tipperprep', 'BodyBuilder Functions', 'Bogiedistance', 'Brake System', 'Bumper and Underrun Protection', 'Cab', 'Chassis AdaptationA', 'Chassis AdaptationB', 'Chassis General', 'Chassis Lev System', 'Colour External', 'Cooling System', 'Engine', 'Frame', 'Front Axle Suspension', 'Fuel System', 'Gearbox', 'General', 'Lighting External', 'Load Limiter Load Transfer', 'Mudguards', 'Power Supply', 'Powertrain', 'PTO', 'Rear Axle Suspension', 'SCR system', 'Spare Wheel Carrier', 'Steering System', 'Trailer Connections', 'Type Program', 'Wet Kit', 'Wheel Equipment'];

  $('#the-basics .typeahead').typeahead({
    hint: true,
    highlight: true,
    minLength: 1
  },
  {
    name: 'states',
    source: substringMatcher(states)
  });

  // bloodhound
  // ----------

  // constructs the suggestion engine
  var states = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.whitespace,
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    // `states` is an array of state names defined in "The Basics"
    local: states
  });

  $('#bloodhound .typeahead').typeahead({
    hint: true,
    highlight: true,
    minLength: 1
  },
  {
    name: 'states',
    source: states
  });

  // prefetch
  // --------


  // rtl
  // ---

  var arabicPhrases = new Bloodhound({
    datumTokenizer: Bloodhound.tokenizers.whitespace,
    queryTokenizer: Bloodhound.tokenizers.whitespace,
    local: [
      "الإنجليزية",
      "نعم",
      "لا",
      "مرحبا",
      "أهلا"
    ]
  });

  $('#rtl-support .typeahead').typeahead({
    hint: false
  },
  {
    name: 'arabic-phrases',
    source: arabicPhrases
  });


});

//
//     Copyright © 2011-2019 Cambridge Intelligence Limited. 
//     All rights reserved.
// 
//     Sample Code
//
//!    Help users identify and understand alerts in your networks.
var chart;
var graph;

// Style info
var alertColour = '#b7336a';
var alertBorderColour = 'maroon';
var alertLinkColour = '#b7336a';
var glyphFontColour = 'white';
var iconColour = '#79bdfc';
var nodeColour = '#333';
var linkColour = '#bacad6';

// State tracking
var dragStartState = {};
var pinReveal = [];
var openCombos = {};
var highlighted = [];
var selected;

// Map data values to strings for the Details panel
var osMap = {
  win: 'Windows',
  mac: 'macOS',
  linux: 'Linux',
  phone: 'Android'
};

var typeMap = {
  linux: 'Computer',
  win: 'Computer',
  mac: 'Computer',
  printer: 'Printer',
  phone: 'Smartphone',
  server: 'Server'
};

function klReady(err, loadedChart) {
  chart = loadedChart;

  preprocessData();
  bindChartEvents();

  // Use a graph engine to track relations in the underlying data
  graph = KeyLines.getGraphEngine();
  graph.load(data);

  chart.load(data, function () {
    revealAlertLinks();
    chart.layout('lens', { tightness: 8 });
  });
}

// Initialise the raw data by adding style information
// And populating the right-hand panel with alert information
function preprocessData() {
  data.items.forEach(function (item) {
    // Add some basic style info
    if (item.type === 'node') {
      item.e = 1.3;
      item.c = nodeColour;
      item.b = null;
      item.fbc = 'rgba(0,0,0,0)';
      if (item.fi) {
        if (item.fi.t) {
          item.fi.t = KeyLines.getFontIcon(item.fi.t);
        }
        item.fi.c = iconColour;
      }
      if (item.d && item.d.alert) {
        item.g[0].c = alertColour;
        item.g[0].b = alertBorderColour;
      }
    } else {
      item.c = linkColour;
    }

    if (item.type === 'node') {
      // Add styling to nodes that are going to be promoted to combos
      if (item.d && (item.d.type === 'network' || item.d.type === 'router')) {
        extendObject(item, {
          fi: {
            t: KeyLines.getFontIcon('fa-truck'),
            c: iconColour
          },
          fbc: 'rgba(0,0,0,0)',
          b: null,
          c: nodeColour,
          bw: 4,
          g: getGlyph(item.id)
        });

        if (item.d.type === 'network') {
          item.oc = { c: '#e8effc' };
          item.e = 2;
        }

        if (item.d.type === 'router') {
          item.oc = { bs: 'dashed', bw: 4, c: '#d1dff9' };
          item.e = 1.5;
        }
      }
    }

    if (item.d && item.d.alert) {
      generateAlert(item);
    }
  });
}

function bindChartEvents() {
  // Override default combo open behaviour to
  //  a) Track which combos are currently open
  //  b) Use concentric arrangement
  chart.bind('dblclick', function (item) {
    var node = chart.getItem(item);
    if (node && node.type === 'node' && chart.combo().isCombo(item)) {
      if (chart.combo().isOpen(item)) {
        delete openCombos[item];

        chart.combo().close(item);
      } else {
        openCombos[item] = true;

        chart.combo().arrange(item, { name: 'concentric', animate: false }, function () {
          chart.combo().open(item);
        });
      }
    }

    return true;
  });

  // Disable dragging of links
  chart.bind('dragstart', function (type, id, x, y) {
    dragStartState = { x: x, y: y };
    var item = chart.getItem(id);

    if (item) {
      dragStartState.id = item.id || null;
      if (item.type !== 'link') {
        dragStartState.item = item;
      } else {
        return true;
      }
    }
    return false;
  });

  chart.bind('dragend', function (type, id, x, y) {
    // Detect a click (ie, a drag over a tiny area)
    if (Math.abs(dragStartState.x - x) < 3 && Math.abs(dragStartState.y - y) < 3) {
      select(dragStartState.item);
    }
  });
}

function revealAlertLinks() {
  var alerts = [];
  chart.each({ type: 'link' }, function (link) {
    if (link.d.alert) {
      alerts.push(link.id);
    }
  });

  // Style alerts a bit more dramatically than regular links
  chart.setProperties(alerts.map(function (id) {
    return {
      id: id,
      c: alertLinkColour,
      off: 40,
      g: [{ c: alertColour, b: alertColour, t: '!', e: 1.5 }]
    };
  }));

  chart.combo().reveal(alerts);

  // Make sure alert links are ALWAYS revealed
  pinReveal = alerts;
}

function clearHighlights() {
  chart.setProperties(highlighted.map(function (l) {
    return {
      id: l.id,
      c: l.d && l.d.alert ? alertColour : linkColour,
      t1: null,
      t2: null
    };
  }));

  highlighted = [];
}

// Update foreground state according to what is selected
// If a node: it's the node, its neighbours and the links between
// If a link: it's the nodes at the ends of the link
function updateForeground(id) {
  var toForeground = true;
  var item = chart.getItem(id);

  // If a combo is selected, we foreground based on the items inside that combo
  var underlyingNodes;

  if (item) {
    toForeground = {};
    toForeground[id] = true;
    if (chart.combo().isCombo(id)) {
      // Foreground all items inside the combo
      if (item.type === 'link') {
        addUnderlyingNodes(item.id1);
        addUnderlyingNodes(item.id2);
      } else {
        addUnderlyingNodes(id);
      }
    }

    if (item.type === 'link') {
      toForeground[item.id1] = true;
      toForeground[item.id2] = true;
    } else {
      var neighbours = graph.neighbours(underlyingNodes || id);
      neighbours.nodes.forEach(function (neighbourId) {
        toForeground[neighbourId] = true;
      });
    }
  }

  // Only calculate FG on the nodes - links will work themselves out
  chart.foreground(function (node) {
    return toForeground === true || toForeground[node.id];
  });

  // Find the underlying items of a combo and mark them for foregrounding
  function addUnderlyingNodes(comboId) {
    if (!underlyingNodes) {
      underlyingNodes = [];
    }

    var nodes = chart.combo().info(comboId).nodes;
    underlyingNodes.push.apply(underlyingNodes, nodes.map(function (n) {
      toForeground[n.id] = true;
      return n.id;
    }));
  }
}

function getPortGlyph(link, port) {
  var colour;
  if (link.d.alert) {
    colour = alertLinkColour;
  } else {
    colour = iconColour;
  }

  if (port) {
    return { g: [{ t: port, c: colour, fc: glyphFontColour, b: colour }] };
  }
  return undefined;
}

function highlightNode(id) {
  var neighbours = graph.neighbours(id, { hidden: true });

  var links = neighbours.links.map(function (l) {
    var link = chart.getItem(l);
    highlighted.push(link);

    var colour = link.d.alert ? alertLinkColour : iconColour;

    return {
      id: l,
      c: colour,
      t1: getPortGlyph(link, link.d.port1),
      t2: getPortGlyph(link, link.d.port2)
    };
  });

  chart.setProperties(links);

  var reveal = pinReveal.concat(neighbours.links);
  chart.combo().reveal(reveal);
}

function select(item) {
  clearHighlights();
  chart.combo().reveal(pinReveal);

  var fgTarget;
  var id;
  if (item) {
    id = item.id;
    if (!chart.combo().isCombo(id)) {
      selected = id;
      fgTarget = id;

      if (item.type === 'node') {
        highlightNode(id);
      } else {
        chart.combo().reveal(pinReveal.concat(id));

        highlighted.push(item);
        chart.setProperties({
          id: id,
          c: item.d.alert ? alertLinkColour : iconColour,
          t1: getPortGlyph(item, item.d.port1),
          t2: getPortGlyph(item, item.d.port2)
        });
      }
    }
  } else if (selected) {
    chart.setProperties({ id: selected, t1: null, t2: null });
  }

  updateForeground(fgTarget);
  updateAlerts(id);
  updateUI(item);
}

function hasDescendantWithAlerts(id) {
  var children = data.items.filter(function (item) {
    return item.parentId && item.parentId === id;
  });
  return children.some(function (child) {
    return (child.d && child.d.alert) || hasDescendantWithAlerts(child.id);
  });
}

function getGlyph(id) {
  if (hasDescendantWithAlerts(id)) {
    return [{ c: alertColour, b: alertBorderColour, t: '!', p: 'ne', e: 1.1 }];
  }
  return null;
}

// Add the properties of object a to object b
// Note that this mutates object a
function extendObject(a, b) {
  if (b) {
    Object.keys(b).forEach(function (k) {
      a[k] = b[k];
    });
  }
  return a;
}

// Convenience shortcut
function zoom(ids, callback) {
  chart.zoom('fit', { animate: true, time: 800, ids: ids }, callback);
}

// Reveal, zoom and highlight a particular item
// This 'unwraps' combos layer by layer to show the items inside
function showAlert(itemId) {
  var item = chart.getItem(itemId);
  var layers = []; // unwrap combos one layer at a time
  var toOpen = {};
  var zoomTo;
  if (item.type === 'link') {
    addLayers(chart.getItem(item.id1));
    addLayers(chart.getItem(item.id2));
    zoomTo = [item.id1, item.id2];
  } else {
    addLayers(item);
    zoomTo = itemId;
  }

  select(item);

  // Close any combos which we don't need open
  var close = [];
  Object.keys(openCombos).forEach(function (id) {
    if (!toOpen[id]) {
      delete openCombos[id];
      close.push(id);
    }
  });

  chart.combo().close(close, { time: 800 }, function () {
    // Decide whether to zoom to the item before unwrapping the combos
    if (!isVisible(zoomTo)) {
      zoom(itemId, unwrapLayer);
    } else {
      unwrapLayer();
    }
  });

  // Add any parenting combos for an item to the list of combos to unwrap
  function addLayers(node) {
    var i = 0;
    var n = node.id;
    while (n) {
      var parent = chart.combo().find(n, { parent: 'first' });
      if (parent) {
        if (!layers[i]) {
          layers[i] = [];
        }
        layers[i].push(parent);
        openCombos[parent] = true;
        toOpen[parent] = true;
        n = parent;
      } else {
        n = null;
      }
      i++;
    }
  }

  // Unwrap one layer of combos (ie, combos at the same depths)
  function unwrapLayer() {
    updateForeground(itemId);

    // Get the current topmost layer
    var ids = layers.pop();

    arrange(ids, function () {
      chart.combo().open(ids, { time: 800 }, function () {
        if (layers.length) {
          unwrapLayer();
        } else {
          done();
        }
      });
    });
  }

  function arrange(comboids, callback, indexOpt) {
    var index = indexOpt || 0;

    var comboid = comboids[index];
    if (comboid) {
      chart.combo().arrange(comboid, { animate: false, name: 'concentric' }, function () {
        arrange(comboids, callback, index + 1);
      });
    } else {
      callback();
    }
  }

  function done() {
    zoom(zoomTo, function () {
      if (item.type === 'link') {
        pingItem([item.id, item.id1, item.id2]);
      } else {
        pingItem([item.id]);
      }
    });
  }
}

function pingItem(ids) {
  chart.ping(ids, { c: alertColour, repeat: 1, time: 400 });
}

// Update the Details panel to reflect the currently selection
function updateUI(item) {
  $('.details').toggleClass('hide', true);
  var root;

  if (item) {
    var type = item.d.type;
    // For combo nodes, just display some very basic information
    if (chart.combo().isCombo(item.id)) {
      root = $('.combo.details');
      root.toggleClass('hide', false);

      if (type) {
        type = type[0].toUpperCase() + type.substr(1);
      }
      $('.field.combo-type label').text(type || 'Connection');
      var content;
      if (item.type === 'link') {
        content = chart.getItem(item.id1).t + ' <--> ' + chart.getItem(item.id2).t;
      } else {
        content = item.t;
      }
      $('.field.detail .value').text(content);
    } else {
      // For regular nodes and links, populate more detailed information (including alerts)
      root = $('.' + item.type + '.details');
      root.toggleClass('hide', false);

      if (item.type === 'node') {
        root.find('.field.ip .value').text(item.t);

        root.find('.field.type .value').text(typeMap[type]);

        var os = item.d.type;
        root.find('.field.os .value').text(osMap[os] || '-');

        var host = item.d.network;
        root.find('.field.host .value').text(host);
      } else {
        var src = chart.getItem(item.id1);
        root.find('.field.from .value').text(src.t + ':' + item.d.port1);

        var target = chart.getItem(item.id2);
        root.find('.field.to .value').text(target.t + ':' + item.d.port2);
      }

      var msg = '';
      if (item.d.alert) {
        msg = '<li>' + item.d.alert + '</li>';
      } else {
        msg = '<li>None</li>';
      }
      root.find('.field.msg .value').html(msg);
    }
  } else {
    $('.about-details').toggleClass('hide', false);
  }
}

function updateAlerts(selectedId) {
  $('.alert').removeClass('active btn-kl');
  $('.alert[data-id="' + selectedId + '"]').addClass('active btn-kl');
}

function generateAlert(item) {
  var el = document.createElement('input');
  el.setAttribute('type', 'button');
  el.setAttribute('data-id', item.id);
  el.setAttribute('value', item.d.alert);
  el.onclick = function () {
    showAlert(item.id);
  };

  var li = document.createElement('li');
  li.appendChild(el);

  $('.alerts').append(li);
}

// Check whether one or more items is visible within the viewport
function isVisible(itemId) {
  if (itemId.splice) {
    for (var i = 0; i < itemId.length; i++) {
      if (!isVisible(itemId[0])) return false;
    }
    return true;
  }

  var item = chart.getItem(itemId);
  var view = chart.viewOptions();

  // get the view's bounds in world coordinates (minus an offset)
  var topLeft = chart.worldCoordinates(20, 20);
  var bottomRight = chart.worldCoordinates(view.width - 20, view.height - 20);

  // Check whether the item is within that area
  return item.x >= topLeft.x && item.x <= bottomRight.x
          && item.y >= topLeft.y && item.y <= bottomRight.y;
}

function startKeyLines() {


  var options = {
    logo: { u: 'images/Logo.png' },
    selectedLink: {
      c: iconColour
    },
    selectedNode: {
      ha0: {
        c: iconColour,
        w: 4,
        r: 30
      }
    },
    iconFontFamily: 'Font Awesome 5 Free Solid',
    handMode: true,
    imageAlignment: {},
    defaultStyles: {
      comboGlyph: null
    }
  };

  setIconSize('fa-print', 0.8);
  setIconSize('fa-laptop', 0.75);
  setIconSize('fa-phone', 0.8);
  setIconSize('fa-truck', 0.8);
  setIconSize('fa-sitemap', 0.75);
  options.imageAlignment[KeyLines.getFontIcon('fa-sitemap')].dy = -8;

  KeyLines.create({ container: 'klchart', options: options }, klReady);

  function setIconSize(icon, size) {
    options.imageAlignment[KeyLines.getFontIcon(icon)] = { e: size };
  }
}

$(function () {
  WebFont.load({
    custom: {
      families: ['Font Awesome 5 Free Solid']
    },
    active: startKeyLines,
    inactive: startKeyLines
  });
});

//
//     Copyright © 2011-2019 Cambridge Intelligence Limited. 
//     All rights reserved.
// 
//     Sample Code
//!    Investigate social structures and relations in complex email data.

var chart;
var miniChart;

var greyColour = 'rgb(151, 153, 155)';
var selColour = 'rgb(255, 0, 0)';
var hoverColour = 'rgb(255, 0, 0)';
var circleColour = 'rgb(253, 141, 60)';
var band1 = 'rgb(254, 217, 118)';
var band2 = 'rgb(253, 141, 60)';
var band3 = 'rgb(252, 78, 42)';
var band4 = 'rgb(177, 0, 38)';
var tooltipShowing = false;

var zoomOptions = { animate: true, time: 350 };

// the colour map is used for the hover functionality to restore the original colour after the hover
var colourMap = {};

/* function chartLoaded(err, loaded) {
  chart = loaded;

  // Bind a function called when the mouse goes over a node
  chart.bind('hover', nodeTooltip);
  // or tap it on a mobile device
  chart.bind('touchdown', nodeTooltip);

  // In order to make the tooltip less sticky, we can close it as soon as an event happens
  // The tooltip is going to disappear on scroll
  chart.bind('viewchange', closeTooltip);

  chart.load(data, chart.layout);
} */

function nodeTooltip(id) {
  // id is null for the background
  if (id) {
    var item = chart.getItem(id);
    var coordinates = chart.viewCoordinates(item.x, item.y);
    
     /* console.log(item) */
     /*console.log(chart)  */

    var x = coordinates.x;
    var y = coordinates.y;
    /* console.log(item.g[0]) */

    if (item.type === 'node') {

      
      // Establish the gender through the icon
/*       var gender = item.u === 'images/icons/woman.png' ? 'Female' : 'Male';
 */
      // Create the HTML code that is going to fill the tooltip
      var html = Mustache.to_html($('#tt_html').html(), {
        label: item.t,
        email: item.d.email,
        expertise: item.d.expertise
        /* name: item.d.fn,
        surname: item.d.ln */
      });

      // Add it to the DOM
      $('#tooltip-container').html(html);

      var tooltip = $('#tooltip');

      var top = y - (tooltip.height() / 2);

      tooltip.css('left', x).css('top', top);
      showTooltip();
    } else {
      closeTooltip();
    }
  } else {
    closeTooltip();
  }
}

function closeTooltip() {
  var tooltip = $('#tooltip');
  if (tooltipShowing) {
    // hide tooltip if open
    tooltipShowing = false;
    tooltip.fadeOut();
  }
}

function showTooltip() {
  var tooltip = $('#tooltip');
  if (tooltipShowing) {
    // hide tooltip on previous node
    tooltip.hide();
  }
  tooltipShowing = true;
  tooltip.fadeIn();
}

/* $(function () {


  var options = {
    logo: { u: 'images/Logo.png' },
    hover: 100
  };

  KeyLines.create({
    container: 'klchart',
    type: 'chart',
    options: options
  }, chartLoaded);
}); */

function doZoom(name) {
  chart.zoom(name, zoomOptions);
}

function contains(arr, obj) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] === obj) {
      return true;
    }
  }
  return false;
}

function klReady(err, charts) {
  chart = charts[0];
  miniChart = charts[1];

  

  // Bind a function called when the mouse goes over a node
  chart.bind('click', nodeTooltip);
  // or tap it on a mobile device
  chart.bind('touchdown', nodeTooltip);

  // In order to make the tooltip less sticky, we can close it as soon as an event happens
  // The tooltip is going to disappear on scroll
  chart.bind('viewchange', closeTooltip);

  chart.load(data, chart.layout);

  var filteredScania = filterScania(20);
  chart.load(filteredScania, function () {
    chart.zoom('fit', { animate: false }, chart.layout);
  });

  function filterScania(count) {
    var filtered = { type: 'LinkChart', items: [] };
    for (var i = 0; i < data.items.length; i++) {
      if (data.items[i].type === 'node') {
        colourMap[data.items[i].id] = circleColour;
        data.items[i].c = circleColour;
        filtered.items.push(data.items[i]);
      } else {
        var linkcount = data.items[i].d.count;
        if (linkcount > count) {
          data.items[i].t = '';
          colourMap[data.items[i].id] = greyColour;
          data.items[i].c = greyColour;
          filtered.items.push(data.items[i]);
        }
      }
    }
    return filtered;
  }

  function doItems(items, show, selectedId) {
    function itemColour(id) {
      return (id === selectedId) ? selColour : hoverColour;
    }
    var nodes = doIdList(items.nodes, function (id) {
      return {
        id: id,
        fbc: show ? hoverColour : null,
        c: show ? itemColour(id) : colourMap[id]
      };
    });
    var links = doIdList(items.links, function (id) {
      return {
        id: id,
        fbc: show ? hoverColour : null,
        c: show ? itemColour(id) : null
      };
    });
    return nodes.concat(links);
  }

  function doIdList(ids, fn) {
    var propertyList = [];
    for (var i = 0; i < ids.length; i++) {
      propertyList.push(fn(ids[i]));
    }
    return propertyList;
  }

  // this variable keeps hold of the id of the last hovered over thing
  var undoProperties;

  chart.bind('click', function (id, x, y, button, sub) {

     if(sub === 't') {
    /*   $(function () {
        $(id).popover({
          container: 'body'
        })
      }) */

     } 
    
/*     console.log(chart)
    console.log(this) */
/*     $(sub).popover({title:"title", content:"content", container:"body"});
 */
    
    /* if(sub === 't') { */
      /* function(d,i){ */
        
       /*  $(this).popover({title:"title", content:"content", container:"body"});
        } */
        // and/or $(this).tooltip({title:"tooltip - title", container:"body"});
    
  /* } */
      /* $(sub).append("Some appended text."); */
     /*  $(function () {
        $().popover({
          container: 'body'
        })
      }) */
      /* console.log($)

      console.log($.fn) */
     /*  console.log(this)
      console.log(id)
      console.log(sub)
      console.log(button)
      console.log(x)
      console.log(y) */
      /* console.log(id)
      console.log(chart) */
   /*  }  */
  });

  chart.bind('hover', function (id) {
    if (undoProperties) {
      chart.setProperties(undoProperties);
      undoProperties = null;
    }
    if (id) {
      var item = chart.getItem(id);
      
     
      var things;
      if (item.type === 'node') {
        things = chart.graph().neighbours(id);
        things.nodes.push(id); // add the item itself
      } else {
        things = { links: [id], nodes: [item.id1, item.id2] };
      }
      var props = doItems(things, true, id);
      chart.setProperties(props);
      undoProperties = doItems(things, false);
    }
  });

  var loadActive = false;
  var queuedUpItems;

  function loadMiniChart(items) {
    miniChart.load({
      type: 'LinkChart',
      items: items
    }, function () {
      miniChart.layout('standard', {}, function () {
        // do again if there are queued up items
        if (queuedUpItems) {
          var newVar = queuedUpItems;
          queuedUpItems = null;
          loadMiniChart(newVar);
        } else {
          loadActive = false;
        }
      });
    });
  }

  chart.bind('selectionchange', function () {
    var ids = chart.selection();
    var items = [];

    function pushNode(node) {
      node.c = colourMap[node.id];
      node.fbc = undefined;
      node.x = 0;
      node.y = 0;
      items.push(node);
    }

    if (ids.length > 0) {
      // find nearest neighbours
      var neighbours = chart.graph().neighbours(ids);

      // Copy the items from the current chart over to the miniChart.
      // however, because the hover has changed the colours, we need to reset based on the non-hover
      // colour
      chart.each({ type: 'node' }, function (node) {
        if (contains(ids, node.id)) {
          pushNode(node);
        } else if (contains(neighbours.nodes, node.id)) {
          pushNode(node);
        }
      });

      chart.each({ type: 'link' }, function (link) {
        if (contains(neighbours.links, link.id)) {
          link.c = colourMap[link.id];
          items.push(link);
        } else if (contains(ids, link.id)) {
          link.c = colourMap[link.id];
          items.push(link);
        }
      });
    }

    // any selection events which arrive DURING the following calls should be buffered
    // this is to stop the 'bounding box' drag sending nodes across to the miniChart too fast!
    if (!loadActive) {
      loadActive = true;
      loadMiniChart(items);
    } else {
      queuedUpItems = items;
      // note - this just overrides any previously queued items (deliberately)
    }
  });

  chart.bind('dragstart', function (name) {
    // prevent curvy links being made
    return (name === 'offset');
  });

  // prevent the user from being able to delete the selection using the delete key
  chart.bind('delete', function () {
    return true;
  });
}



// this function picks a colour from a range of colours based on the value
function colourPicker(value) {
  if (value < 0.25) {
    return band1;
  }
  if (value < 0.5) {
    return band2;
  }
  if (value < 0.75) {
    return band3;
  }
  return band4;
}

function normalize(max, min, value) {
  if (max === min) {
    return min;
  }

  return (value - min) / (max - min);
}

function miniChartFilter(items, baseColour) {
  var filtered = [];
  var miniItem;
  for (var i = 0; i < items.length; i++) {
    if (miniChart.getItem(items[i].id)) {
      miniItem = { id: items[i].id, c: baseColour ? circleColour : colourMap[items[i].id] };
      // It is a link
      if (items[i].w) {
        miniItem.w = items[i].w;
      } else {
      // this will set some specific colours for miniChart
        miniItem.e = items[i].e;
      }
      filtered.push(miniItem);
    }
  }
  return filtered;
}

function animateValues(values, baseColour) {
  var ids = Object.keys(values);
  var valuesArray = ids.map(function (id) { return values[id]; });

  var max = Math.max.apply(null, valuesArray);
  var min = Math.min.apply(null, valuesArray);

  var items = ids.map(function (id) {
    // Normalize the value in the range 0 -> 1
    var value = normalize(max, min, values[id]);

    // enlarge nodes with higher values
    var enlargement = (value * 6) + 1;

    // choose a colour
    var colour = baseColour ? circleColour : colourPicker(value);

    return { id: id, e: enlargement, c: colour };
  });

  // we then store the colour in a colourMap
  items.forEach(function (item) {
    colourMap[item.id] = item.c;
  });

  var miniItems = miniChartFilter(items, baseColour);

  chart.animateProperties(items, { time: 500 }, function () {
    chart.layout('standard', {}, function () {
      miniChart.animateProperties(miniItems, { time: 500 }, function () {
        miniChart.layout();
      });
    });
  });
}

function same(options, callback) {
  var sizes = {};
  chart.each({ type: 'node' }, function (node) {
    sizes[node.id] = 0;
  });
  callback(sizes);
}

function wrapCallback(fn) {
  return function (options, callback) {
    var result = fn(options);
    callback(result);
  };
}

function analysis(callback) {
  var options = {};

  var name = analysisName();

  if (useWeights()) {
    setWeights(options, name);
  }

  setDirection(options, name);
  var fn = analysisFunction(name);

  fn(options, function (values) {
    animateValues(values, name === 'same');
    if (callback) {
      callback();
    }
  });
}

function analysisFunction(name) {
  switch (name) {
    case 'degree':
      return wrapCallback(chart.graph().degrees);
    case 'closeness':
      return chart.graph().closeness;
    case 'betweenness':
      return chart.graph().betweenness;
    case 'pagerank':
      return wrapCallback(chart.graph().pageRank);
    case 'eigenvector':
      return wrapCallback(chart.graph().eigenCentrality);
    case 'same':
    default:
      return same;
  }
}

// returns the name of the type of analysis from the DOM
function analysisName() {
  if ($('#degree').hasClass('active')) {
    return 'degree';
  }
  if ($('#closeness').hasClass('active')) {
    return 'closeness';
  }
  if ($('#betweenness').hasClass('active')) {
    return 'betweenness';
  }
  if ($('#pagerank').hasClass('active')) {
    return 'pagerank';
  }
  if ($('#eigenvector').hasClass('active')) {
    return 'eigenvector';
  }
  return 'same';
}

function setDirection(options, name) {
  if (name === 'betweenness' || name === 'pagerank') {
    options.directed = direction() !== 'any';
  } else {
    options.direction = direction();
  }
}

function setWeights(options, name) {
  if (name.match(/^(betweenness|closeness)$/)) {
    options.weights = true;
  }
  options.value = 'count';
}

function direction() {
  if ($('#sending').hasClass('active')) {
    return 'from';
  }
  if ($('#receiving').hasClass('active')) {
    return 'to';
  }
  return 'any';
}

function useWeights() {
  return $('#volumeOn').hasClass('active');
}

function linkAnimationSettings(showValue) {
  var links = [];
  chart.each({ type: 'link' }, function (link) {
    var linkcount = link.d.count;
    var width = 1;
    if (showValue) {
      if (linkcount > 300) {
        width = 36;
      } else if (linkcount > 200) {
        width = 27;
      } else if (linkcount > 100) {
        width = 18;
      } else if (linkcount > 50) {
        width = 9;
      }
    }
    links.push({ id: link.id, w: width });
  });
  return links;
}


$(function () {

  var options = {
    logo: { u: 'images/Logo.png' },
    hover: 100
  };



  KeyLines.create([
    // Big chart with options
    { container: 'klchart', options: { arrows: 'large', handMode: true, hover: 5, navigation: { shown: false }, overview: { icon: false }, selectionColour: selColour, logo: { u: 'images/Logo.png' } } },
    // Small chart with options
    { container: 'minikl', options: { arrows: 'large', handMode: true, navigation: { shown: false }, overview: { icon: false }, selectionColour: selColour } }
  ], klReady);

  // Custom overlay code:
  $('#home').click(function () {
    doZoom('fit');
  });
  $('#zoomIn').click(function () {
    doZoom('in');
  });
  $('#zoomOut').click(function () {
    doZoom('out');
  });
  $('#changeMode').click(function () {
    var hand = !!chart.options().handMode; // be careful with undefined
    hand = !hand;
    chart.options({ handMode: hand });
    $('#iconMode').toggleClass('fa-arrows-alt fa-edit');
  });
  $('#layout').click(function (evt) {
    chart.layout(evt.shiftKey ? 'structural' : 'standard');
  });

  $('.volume').click(function () {
    $('.volume').toggleClass('active btn-kl');

    var links = linkAnimationSettings(useWeights());
    var miniItems = miniChartFilter(links, false);
    chart.animateProperties(links, {}, function () {
      analysis(function () {
        miniChart.animateProperties(miniItems, { time: 500 }); // fire and forget
      });
    });
  });

  $('.size').click(function () {
    $('.size').removeClass('active btn-kl');
    $(this).addClass('active btn-kl');

    analysis();
  });

  $('.direction').click(function () {
    $('.direction').removeClass('active btn-kl');
    $(this).addClass('active btn-kl');

    analysis();
  });
});

If you run this demo from the filesystem, some functionality may not work. You should serve it from a web server instead. 

If you are using Node.js as your web server, you should first install Express by running:

> npm install express

You can then start your web server by running:

> node server.js

If you can't run Node or Express, just use a simple Python server:

 > python -m SimpleHTTPServer 8080

Then you can navigate to https://localhost:8080 in your web browser to see the demo running.

Note: If the demo relies on a database (e.g. the Neo4j or Titan demos) then you will have to set up your database and load the data in order for it to work.
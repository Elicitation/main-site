//
//     Copyright © 2011-2019 Cambridge Intelligence Limited.
//     All rights reserved.
//     KeyLines v5.3.1-27713
//
declare module KeyLines {
  
  interface IdMap<T> {
    [key: string]: T
  }

  interface ChartData {
    /** A KeyLines Chart type - must be exactly 'LinkChart' */
    type: 'LinkChart',
    /** An array of nodes and links */
    items: Array<Node | Link | Shape>
  }
      
  interface NodeStyle {
    /** The border colour. Default: No border. */
    b?: string,
    /** Whether the node is displayed in the background. Default: false. */
    bg?: boolean,
    /** The style of the border line. This can be either 'solid' or 'dashed'. Default: 'solid'. */
    bs?: "solid" | "dashed",
    /** An object describing the bubble shown on the node. */
    bu?: Bubble,
    /** The width of the node's border. Default: 4. */
    bw?: number,
    /** The fill colour. Default: No fill. */
    c?: string,
    /** Whether the image should be a cutout circle from the original image. Does not apply to font icons. Default: false. */
    ci?: boolean,
    /** The 'd' parameter stands for data. Use this to store custom data on the node. */
    d?: any,
    /** An object describing the donut border shown on the node. Only applies to nodes with 'circle' shape. If both donut and b are set then donut takes precedence. */
    donut?: Donut,
    /** The timestamp of the node. You can either use 'dt' to specify a point time or 'dt1' and 'dt2' to set a start and end of a time period */
    dt?: any,
    /** [deprecated] Whether this is a dummy node. Dummy nodes are drawn as the ends of a dumbbell, for links which typically have just been created by dragging onto the chart surface. Default: false. */
    du?: boolean,
    /** The enlargement factor for the node. Default: 1. */
    e?: number,
    /** Whether the label should be displayed in bold font. Default: false. */
    fb?: boolean,
    /** The background colour of the font. The default is a subtle effect using white with an alpha channel. */
    fbc?: string,
    /** The colour for the label font. Default: black. */
    fc?: string,
    /** The font family to use for the label. The default comes from the chart.options fontFamily setting. */
    ff?: string,
    /** The font icon used on the node. */
    fi?: FontIcon,
    /** The font size (pt) of the node label. Default: 14. */
    fs?: number,
    /** An array of objects describing the glyphs shown on the node. */
    g?: Array<Glyph>,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha0?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha1?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha2?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha3?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha4?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha5?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha6?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha7?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha8?: Halo,
    /** The halos shown on the node. There are ten halo properties, ha0, ha1, ha2, etc., up to ha9. */
    ha9?: Halo,
    /** Whether the node is hidden. See also show and hide. Default: false. */
    hi?: boolean,
    /** The style of a combo when open. */
    oc?: OpenStyleOptions,
    /** The id of the parent node, if it is a member of a combo. Can be set explicitly during combo creation; after that you should use chart.combo().transfer to change it. */
    parentId?: string,
    /** An object describing the position of the node on the map when in map mode. */
    pos?: Location,
    /** The node's shape. Options are: 'box', 'circle'. Default: 'circle'. */
    sh?: "box" | "circle",
    /** The node label. Use new lines for multiline labels. Default: No label. */
    t?: string,
    /** If the tc parameter ('text centre') is true, the label is shown in the centre of the node. If it is false then the label is shown at the bottom of the node. Default: false for nodes with images, true for other nodes. */
    tc?: boolean,
    /** The type of the item: this must be exactly 'node' for shapes. */
    type?: 'node',
    /** The URL of the node image. */
    u?: string,
    /** The node position along the X-axis, in world coordinates. Default: 0. */
    x?: number,
    /** The node position along the Y-axis, in world coordinates. Default: 0. */
    y?: number
  }
      
  interface OpenStyleOptions {
    /** The colour of the open combo's border. Default: grey. */
    b?: string,
    /** The style of the border line. This can be either 'solid' or 'dashed'. Default: solid. */
    bs?: string,
    /** The width of the open combo's border. Default: 1. */
    bw?: number,
    /** The colour of the open combo. Default: light grey. */
    c?: string,
    /** Whether resize handles should be shown. Default: false. */
    re?: boolean,
    /** The width of the open combo. When the combo is created, this is set to fit all child nodes */
    w?: number
  }
      
  interface NodeProperties extends NodeStyle {
    /** The identity of this node. This must be unique across all items in the chart. It must not start with an underscore or end with a '\' character. */
    id: string
  }
      
  interface Node extends NodeProperties {
    /** The type of the item: this must be exactly 'node' for nodes. */
    type: 'node'
  }
      
  interface LinkStyle {
    /** Whether to show an arrow at the id1 end. Default: false. */
    a1?: boolean,
    /** Whether to show an arrow at the id2 end. Default: false. */
    a2?: boolean,
    /** The distance to back-off from end id1 as a ratio of the total length of the link line. Value in the range 0 to 1. Default: 0. */
    b1?: number,
    /** The distance to back-off from end id2 as a ratio of the total length of the link line. Value in the range 0 to 1. Default: 0. */
    b2?: number,
    /** Whether the link is displayed in the background. Default: false. */
    bg?: boolean,
    /** An object describing the bubble shown on the link. */
    bu?: Bubble,
    /** The colour of the link line itself. Default: grey. */
    c?: string,
    /** If specified, the link will have a colour gradient, with colour c at the id1 end and colour c2 at the id2 end. The linkStyle transition setting controls the gradient's appearance. */
    c2?: string,
    /** The 'd' parameter stands for data. Use this to store custom data on the link. */
    d?: any,
    /** The timestamp of the link. You can either use 'dt' to specify a point time or 'dt1' and 'dt2' to set a start and end of a time period */
    dt?: any,
    /** Whether the label should be displayed in bold font. Default: false. */
    fb?: boolean,
    /** The background colour of the font. The default is a subtle effect using white with an alpha channel. */
    fbc?: string,
    /** The colour for the label font. Default: black. */
    fc?: string,
    /** The font family to use for the label. The default comes from the chart.options fontFamily setting. */
    ff?: string,
    /** The font size (pt) of the link label. Default: 14. */
    fs?: number,
    /** An array of objects describing the glyphs shown next to the link label. */
    g?: Array<Glyph>,
    /** Whether the link is hidden. See also show and hide. Default: false. */
    hi?: boolean,
    /** The style of the link line. This can be either 'solid', 'dashed' or 'dotted'. Default: 'solid'. */
    ls?: "solid" | "dashed" | "dotted",
    /** Specifies the offset of the midpoint of the link, and so controls how curved the link is. A zero offset gives a straight line for links between two different nodes. For self links, it specifies how far the link is offset from its default position close to the node. Increasing the offset value increases the size of the arc. Default: 0. */
    off?: number,
    /** The id of the parent combo or link (if it is a member of a combo). Note that parentIds for links are calculated automatically and cannot be set. */
    parentId?: string,
    /** The label positioned at the centre of the link. Use new lines for multiline labels. */
    t?: string,
    /** The link label positioned at the id1 end. Use new lines for multiline labels. Can be one of the following options:string - Add a new label to inherit properties from the label at the centre of the link.LinkEndLabel - Use LinkEndLabel properties. */
    t1?: string | LinkEndLabel,
    /** The link label positioned at the id2 end. Use new lines for multiline labels. Can be one of the following options:string - Add a new label to inherit properties from the label at the centre of the link.LinkEndLabel - Use LinkEndLabel properties. */
    t2?: string | LinkEndLabel,
    /** The width of the link line. If you add arrows to links, this width will affect the size of the arrowheads. Default: 1. */
    w?: number
  }
      
  interface LinkEndLabel {
    /** Whether the label should be displayed in bold font. The default is inherited from the link's fb setting. */
    fb?: boolean,
    /** The background colour of the font. The default is inherited from the label at the centre of the link. */
    fbc?: string,
    /** The colour for the label font. The default is inherited from the label at the centre of the link. */
    fc?: string,
    /** The font family to use for the label. The default is inherited from the label at the centre of the link. */
    ff?: string,
    /** The font size (pt) of the link label. The default is inherited from the label at the centre of the link. */
    fs?: number,
    /** An array of objects describing the glyphs shown next to the link label. */
    g?: Array<Glyph>,
    /** The link label. Use new lines for multiline labels. */
    t?: string
  }
      
  interface LinkProperties extends LinkStyle {
    /** The identity of this link. This must be unique across all items in the chart. It must not end with a '\' character. */
    id: string
  }
      
  interface Link extends LinkProperties {
    /** The identity of the node at one end of the link. */
    id1: string,
    /** The identity of the node at the other end of the link. This may be the same as id1 to create a "self link" if the selfLinks chart option is enabled. */
    id2: string,
    /** The type of the item: this must be exactly 'link' for links. */
    type: 'link'
  }
      
  interface ShapeStyle {
    /** The border colour. Default: No border. */
    b?: string,
    /** The style of the border line. This can be either 'solid' or 'dashed'. Default: 'solid'. */
    bs?: "solid" | "dashed",
    /** The width of the shape's border. Default: 4. */
    bw?: number,
    /** Whether the shape is displayed in the background. Default: false. */
    bg?: boolean,
    /** An object describing the bubble shown on the shape. */
    bu?: Bubble,
    /** The fill colour. Default: No fill. */
    c?: string,
    /** Whether the image should be a cutout circle from the original image. Does not apply to font icons. Default: false. */
    ci?: boolean,
    /** The 'd' parameter stands for data. Use this to store custom data on the shape. */
    d?: any,
    /** The timestamp of the shape. You can either use 'dt' to specify a point time or 'dt1' and 'dt2' to set a start and end of a time period */
    dt?: any,
    /** Whether the label should be displayed in bold font. Default: false. */
    fb?: boolean,
    /** The background colour of the font. The default is a subtle effect using white with an alpha channel. */
    fbc?: string,
    /** The colour for the label font. Default: 'black'. */
    fc?: string,
    /** The font family to use for the label. The default comes from the chart.options fontFamily setting. */
    ff?: string,
    /** The font icon used on the shape. */
    fi?: FontIcon,
    /** The font size (pt) of the shape label. Default: 14. */
    fs?: number,
    /** An array of objects describing the glyphs shown on the shape. */
    g?: Array<Glyph>,
    /** The height of the shape in world coordinates. Default: 0. */
    h?: number,
    /** Whether the shape is hidden. See also show and hide. Default: false. */
    hi?: boolean,
    /** The id of the parent node, if it is a member of a combo. Can be set explicitly during combo creation; after that you should use chart.combo().transfer to change it. */
    parentId?: string,
    /** The position of the shape on the map when in map mode. */
    pos?: Location,
    /** Whether resize handles should be shown. Default: false. */
    re?: boolean,
    /** The node's shape. Options are: 'box', 'circle'. Default: 'box'. */
    sh?: "box" | "circle",
    /** The shape label. Use new lines for multiline labels. Default: No label. */
    t?: string,
    /** If the tc parameter ('text centre') is true, the label is shown in the centre of the shape. If it is false then the label is shown at the bottom of the shape. Default: false. */
    tc?: boolean,
    /** The type of the item: this must be exactly 'node' for shapes. */
    type: 'node',
    /** The URL of the node image. */
    u?: string,
    /** The width of the shape in world coordinates. */
    w?: number,
    /** The node position along the X-axis, in world coordinates. Default: 0. */
    x?: number,
    /** The node position along the Y-axis, in world coordinates. Default: 0. */
    y?: number
  }
      
  interface ShapeProperties extends ShapeStyle {
    /** The identity of this node. This must be unique across all items in the chart. It must not start with an underscore or end with a '\' character. */
    id: string
  }
      
  interface Shape extends ShapeProperties {
    /** The height of the shape in world coordinates. Default: 0. */
    h: number,
    /** The type of the item: this must be exactly 'node' for nodes. */
    type: 'node',
    /** The width of the shape in world coordinates. */
    w: number
  }
      
  interface Bubble {
    /** The colour of the bubble border. Default: grey. */
    b?: string,
    /** The colour of the bubble fill. Default: 'white'. */
    c?: string,
    /** Whether the bubble text should be displayed in bold font. Default: false. */
    fb?: boolean,
    /** The colour for the bubble text font. Default: 'black'. */
    fc?: string,
    /** The font family to use for the bubble text. The default comes from the chart.options fontFamily setting. */
    ff?: string,
    /** The font size (pt) of the bubble text. Default: 14. */
    fs?: number,
    /** An object describing the glyph shown in the bubble. Note that this is a single object, not an array. */
    g?: Glyph,
    /** The position of the bubble relative to the node or link. Four positions are supported - 
    'ne', 'se', 'sw' and 'nw'. Default: 'ne'. */
    p?: "ne" | "se" | "sw" | "nw",
    /** The text for the bubble. */
    t: string
  }
      
  interface Glyph {
    /** Set to true for an animated glyph. Default: false. */
    a?: boolean,
    /** The colour of the glyph border. Default: grey. */
    b?: string,
    /** The colour of the glyph fill. If colour is specified then the image will be shown inside the glyph. If no colour is specified then the image replaces the glyph circle and no label is shown. */
    c?: string,
    /** The enlargement factor for the glyph. Default: 1. */
    e?: number,
    /** Whether the glyph's label should be displayed in bold. Default: true. */
    fb?: boolean,
    /** The font colour for the glyph's label. Default: 'white'. */
    fc?: string,
    /** The font family to use for the glyph's label. The default comes from the chart.options fontFamily setting. */
    ff?: string,
    /** The font icon to use as a glyph. */
    fi?: FontIcon,
    /** The position of the glyph relative to the node. Glyph positions are only supported on nodes. Use compass points ('n', ne', 'e', 'se', 's', 'sw', 'w' and 'nw') or integers representing angles measured in degrees clockwise from north (in the range 0-359). */
    p?: "n" | "ne" | "e" | "se" | "s" | "sw" | "w" | "nw" | number,
    /** Overrides the distance from the centre of the node at which the glyph is drawn. Only available when the glyph's position is a number - ignored when position is a compass point. If 'r' is specified, link ends will no longer avoid the glyph. */
    r?: number,
    /** The label for the glyph. If a label is specified then it takes precedence over the image. For standard glyphs, with 'w' false, a maximum of four characters can be shown. For wide glyphs, with 'w' true,
    a maximum of 25 characters can be shown. Longer labels are truncated. */
    t?: string,
    /** The URL of the image to use for the glyph. The image can be any size, but 64X64 should be adequate. */
    u?: string,
    /** Set to true to extend the width of the glyph circle to form a rounded rectangle. Only applies to glyphs on nodes and not to glyphs on links, bubbles or glyph-only nodes. . Default: false. */
    w?: boolean
  }
      
  interface FontIcon {
    /** The colour of the font icon fill. Default: 'black'. */
    c?: string,
    /** The font family to use for the font icon. The default comes from the chart.options iconFontFamily setting. */
    ff?: string,
    /** The font icon to show. If the content is a string then it will be directly shown. Otherwise the value will be used to find the appropriate font icon within the UNICODE space. */
    t: string | number
  }
      
  interface Halo {
    /** The colour of the halo. */
    c: string,
    /** The radius of the halo. */
    r: number,
    /** The width of the halo. */
    w: number
  }
      
  interface Donut {
    /** The colour of the border between donut segments. Default: 'white'. */
    b?: string,
    /** The width of the border between donut segments. Default: 2. */
    bw?: number,
    /** An array giving the colour of each segment. It should contain the same number of elements as the v array. If not supplied, a default set of colours is used. Default: standard colours. */
    c?: Array<string>,
    /** An array giving the size of each segment. Values should be positive. Segments are positioned clockwise around the node starting at the top. */
    v: Array<number>,
    /** The width of the donut segments. This doesn't include the border. Default: 10. */
    w?: number
  }
      
  interface Location {
    /** The latitude in degrees that this node is positioned at when in map mode. Should be in the range -90 to 90, but larger values will be rounded to ±90 respectively */
    lat: number,
    /** The longitude in degrees that this node is positioned at when in map mode. Should be in the range -180 to 180 but larger values will wrap at the antimeridian. */
    lng: number
  }
      
  interface TimeBarData {
    /** This is the object for loading data into the time bar. */
    items: Array<TimeBarItem>
  }
      
  interface TimeBarItem {
    /** The time entry or time entries associated with this item. Either a single time entry or an array of time entries may be supplied. Each time entry may be either a JavaScript Date object, a millisecond number, or a TimePeriod object. */
    dt: Date | number | TimePeriod | Array<Date | number | TimePeriod>,
    /** The identity that this item is associated with. It must not end with a '\' character. */
    id: string,
    /** The value associated with each time entry, for example, the amount of a transaction.
    Values should be greater than zero. The same number of values should be supplied as the number of time entries. If values are not supplied, then the time bar counts the number of timestamps, instead of adding up the corresponding values. Default: 1. */
    v?: number | Array<number>
  }
      
  interface TimePeriod {
    /** The timestamp for the start of the time period, either a JavaScript Date object or a millisecond number. */
    dt1?: Date | number,
    /** The timestamp for the end of the time period, either a JavaScript Date object or a millisecond number. */
    dt2?: Date | number
  }
    
  interface AnimatePropertiesOptions {
    /** The time the animation should take, in milliseconds. Default: 1000. */
    time?: number,
    /** The easing function to use: 'linear': Speed is constant during animation.'cubic': Animation starts slow, speeds up, then finishes slow. Default: 'linear'. */
    easing?: "linear" | "cubic",
    /** If true, the animation is queued until all previous queued animations have completed. If false, the animation begins immediately. Default: true. */
    queue?: boolean
  }
      
  interface ArrangeOptions {
    /** Whether the result should be animated. Default: true. */
    animate?: boolean,
    /** Fit the chart into the window at the end of the arrangement. Default: false. */
    fit?: boolean,
    /** Controls the position of the group of arranged nodes. The options are: 'absolute', 'average' or 'tidy'. Default: 'average'. */
    position?: "absolute" | "average" | "tidy",
    /** A number (0 -> 10) which controls how close the nodes should be. Higher values make the nodes closer. Default: 5. */
    tightness?: number,
    /** If animated, the time the animation should take, in milliseconds. Default: 700. */
    time?: number,
    /** When position is set to absolute, the x coordinate of the centre of the nodes. Default: 0. */
    x?: number,
    /** When position is set to absolute, the y coordinate of the centre of the nodes. Default: 0. */
    y?: number
  }
      
  interface ShapeOptions {
    /** The height of the shape. */
    h: number,
    /** The type of shape: either 'box' or 'circle'. Default: 'box'. */
    sh?: "box" | "circle",
    /** The width of the shape. */
    w: number,
    /** The centre of the shape along the X-axis. */
    x: number,
    /** The centre of the shape along the Y-axis. */
    y: number
  }
      
  interface CreateLinkOptions {
    /** An object describing the style of the new link. Any non-required Link object properties can be passed (i.e., all except for id, id1, id2 and type). Note that the off property cannot be set using createLink */
    style?: LinkStyle
  }
      
  interface EachOptions {
    /** Either 'all', 'node', or 'link'. Default: 'all'. */
    type?: "node" | "link" | "all",
    /** The chart items to iterate over when using combos. Options are: 'underlying': iterates over items that are not combo nodes or combo links.'toplevel': iterates over items, including combos, that are not inside other combos.'all': iterates over every item.. Default: 'underlying'. */
    items?: "underlying" | "toplevel" | "all"
  }
      
  interface ExpandLayoutOptions {
    /** The name of the layout to apply - 'standard', 'organic', 'hierarchy', 'sequential', 'lens', 'radial' or 'tweak'. By default it applies the 'standard' layout, but without performing the fit chart to window and tidy options. Other layouts are not supported. Default: 'standard'. */
    name?: "standard" | "organic" | "hierarchy" | "radial" | "tweak",
    /** Specifies which nodes should be fixed in position when the layout is run. The options are: 'all', 'none', 'adjacent' and 'nonadjacent'. 'fix' only applies to 'standard' and 'tweak' layouts. Default: 'nonadjacent'. */
    fix?: "all" | "none" | "adjacent" | "nonadjacent",
    /** If set to true, each layout run will produce the same chart display for the same chart structure. If false, the layout will produce different results for a given network on each run. Only used for 'standard', 'organic' and 'lens' layouts. Default: false. */
    consistent?: boolean,
    /** The easing function to use: 'linear': Speed is constant during animation.'cubic': Animation starts slow, speeds up, then finishes slow. Default: 'cubic'. */
    easing?: "linear" | "cubic",
    /** Fit the chart into the window at the end of the layout. Default: false. */
    fit?: boolean,
    /** If true, the hierarchy will be flattened by removing extra space between levels. Default: false. */
    flatten?: boolean,
    /** The name of the custom property that defines which level a node belongs to in the 'hierarchy', 'radial' and 'sequential' layouts. Custom properties are set on the 'd' property of nodes. The levels on the nodes must be numbers.
    The lowest number represents the level at the top of the hierarchy.        Requirement depends on which layout you use: 'hierarchy' and 'radial' layouts: required unless the top option is specified. If both 'level' and 'top' are specified, 'top' is ignored.'sequential' layout: required. No option to specify 'top'. */
    level?: string,
    /** The orientation of the hierarchy layout. There are four orientations available: 'up', 'down', 'left' and 'right'. Default: 'down'. */
    orientation?: "down" | "right" | "up" | "left",
    /** How to space nodes at each level of the sequential layout. Options are 'auto', 'equal', and 'stretched'. Default: 'auto'. */
    spacing?: string,
    /** If true, curved links are straightened. If false, they remain curved. Default: true. */
    straighten?: boolean,
    /** The tidy option pushes apart the components of the chart so they don't overlap. Not used for 'organic' or 'lens'. Default: false. */
    tidy?: boolean,
    /** A number (0 -> 10) which controls how close the nodes should be. Higher values make the nodes closer. Default: 5. */
    tightness?: number,
    /** A node id or an array of node ids which should be at the top of the hierarchy/centre of the radial layout. 
    Required for the 'hierarchy' and 'radial' layouts, unless the level option is specified. If both 'level' and 'top' are specified, 'top' is ignored. */
    top?: string | Array<string>
  }
      
  interface ExpandArrange {
    /** Controls how nodes are arranged inside an open combo. Possible values are: 'lens' - items are arranged automatically with connected nodes next to each other.'concentric' - items are arranged inside a circle with larger items at the centre.'none' - items are kept in their original positions.. Default: 'lens'. */
    name?: string,
    /** If true, any combos that are arranged will be resized to fit their contents. If false, they will not be resized, unless the contents are beyond the current boundary. Default: true. */
    resize?: boolean
  }
      
  interface ExpandFilter {
    /** A function which takes an item as its argument, returning true if the item should be visible, false otherwise. */
    filterFn?: Function,
    /** The chart items to iterate over when using combos. Options are: 'underlying': iterates over items that are not combo nodes or combo links.'toplevel': iterates over items, including combos, that are not inside other combos.. Default: 'underlying'. */
    items: "underlying" | "toplevel",
    /** Whether isolated nodes should be hidden, even if the filter function returns true for them. The default is true if type is 'link', false otherwise. */
    hideSingletons?: boolean,
    /** The type of item to show or hide - either 'node', 'link' or 'all'. Default: 'all'. */
    type?: "node" | "link" | "all",
    /** If items is 'underlying', update the text of the glyph on combo nodes to equal the number of nodes that are visible inside the combo node. Default: true. */
    updateGlyph?: boolean
  }
      
  interface ExpandOptions {
    /** Whether the result should be animated. Default: true. */
    animate?: boolean,
    /** The time the animation should take, in milliseconds. Default: 1000. */
    time?: number,
    /** An object specifying the layout to apply to the incoming items if there has been a change to the top-level structure of the chart. */
    layout?: ExpandLayoutOptions,
    /** An object specifying how the contents of any combos which have changed should be arranged. */
    arrange?: ExpandArrange,
    /** An object with the filter definition to apply to the chart items before running the layout. This object can have any option passed to the chart.filter() function (apart from animate and time) plus an additional one: filterFn. */
    filter?: ExpandFilter
  }
      
  interface ComboNodeFilterResult {
    /** The id of the combo that has been updated */
    id: string,
    /** The visible node items inside of this combo */
    nodes?: Array<Node>,
    /** The visible link items inside of this combo */
    links?: Array<Link>
  }
      
  interface ComboLinkFilterResult {
    /** The id of the combo that has been updated */
    id: string,
    /** The visible link items inside of this combo */
    links?: Array<Link>
  }
      
  interface FilterResult {
    /** The items that were shown by the filter function. */
    shown?: {
      /** The array of node ids shown by the filter function. */
      nodes?: Array<string>,
      /** The array of link ids shown by the filter function. */
      links?: Array<string>
    }
    /** The items that were hidden by the filter function. */
    hidden?: {
      /** The array of node ids hidden by the filter function. */
      nodes?: Array<string>,
      /** The array of link ids hidden by the filter function */
      links?: Array<string>
    }
    /** List the combos that have been updated */
    combos?: {
      /** An array of combo nodes that have been updated by this filter */
      nodes?: Array<ComboNodeFilterResult>,
      /** An array of combo links that have been updated by this filter */
      links?: Array<ComboLinkFilterResult>
    }
  }
      
  interface FilterOptions {
    /** Whether the filtering operation should be animated. Default: true. */
    animate?: boolean,
    /** Whether isolated nodes should be hidden, even if the filter function returns true for them. The default is true if type is 'link', false otherwise. */
    hideSingletons?: boolean,
    /** The time the animation should take, in milliseconds. Default: 1000. */
    time?: number,
    /** The type of item to show or hide. Either 'node', 'link' or 'all'. Default: 'all'. */
    type?: "node" | "link" | "all",
    /** The chart items to iterate over when using combos. Options are: 'underlying': iterates over items that are not combo nodes or combo links.'toplevel': iterates over items, including combos, that are not inside other combos.. Default: 'underlying'. */
    items?: "underlying" | "toplevel",
    /** If items is 'underlying', update the text of the glyph on combo nodes to equal the number of nodes that are visible inside the combo node. Default: true. */
    updateGlyph?: boolean
  }
      
  interface ForegroundResult {
    /** The items that were foregrounded by the foreground function. */
    foreground?: {
      /** The array of node ids foregrounded by the foreground function. */
      nodes?: Array<string>,
      /** The array of link ids foregrounded by the foreground function. */
      links?: Array<string>
    }
    /** The items that were backgrounded by the foreground function. */
    background?: {
      /** The array of node ids backgrounded by the foreground function. */
      nodes?: Array<string>,
      /** The array of link ids backgrounded by the foreground function */
      links?: Array<string>
    }
  }
      
  interface ForegroundOptions {
    /** The type of item to foreground/background - either 'node', 'link' or 'all'. Default: 'node'. */
    type?: "node" | "link" | "all",
    /** The chart items to iterate over when using combos. Options are: 'underlying': iterates over items that are not combo nodes or combo links.'toplevel': iterates over items, including combos, that are not inside other combos.. Default: 'underlying'. */
    items?: "underlying" | "toplevel",
    /** Defines whether an open combo can be put in the foreground. Set this to false to put all open combos in the background. Default: true. */
    foregroundOpenCombos?: boolean
  }
      
  interface HideOptions {
    /** Whether the transition should be animated. Default: false. */
    animate?: boolean,
    /** The time the animation should take, in milliseconds. Default: 1000. */
    time?: number
  }
      
  interface LabelPosition {
    /** Left */
    x1: number,
    /** Right */
    x2: number,
    /** Top */
    y1: number,
    /** Bottom */
    y2: number,
    /** Font Size at current zoom */
    fs: number
  }
      
  interface LayoutOptions {
    /** Whether the result should be animated. Default: true. */
    animate?: boolean,
    /** If set to true, each layout run will produce the same chart display for the same chart structure. Their position on the chart may change during the layout, but their position in relation to other nodes will remain the same. If false, the layout will produce different results for a given network on each run. Only used for 'standard', 'organic', 'structural' and 'lens' layouts. Default: false. */
    consistent?: boolean,
    /** The easing function to use: 'linear': Speed is constant during animation.'cubic': Animation starts slow, speeds up, then finishes slow. Default: 'cubic'. */
    easing?: "linear" | "cubic",
    /** Fit the chart into the window at the end of the layout. Default: true. */
    fit?: boolean,
    /** An array of node ids whose positions are fixed relative to the other nodes in the same component. Their position on the chart may change during the layout, but their position in relation to the component's other nodes will remain the same. Only used for the 'standard' and 'tweak' layouts. */
    fixed?: Array<string>,
    /** Only used on 'hierarchy' layout. If true, the hierarchy will be flattened by removing extra space between levels. Default: false. */
    flatten?: boolean,
    /** The name of the custom property that defines which level a node belongs to in the 'hierarchy', 'radial' and 'sequential' layouts. Custom properties are set on the 'd' property of nodes. The levels on the nodes must be numbers.
    The lowest number represents the level at the top of the hierarchy.              Requirement depends on which layout you use: 'hierarchy' and 'radial' layouts: required unless the top option is specified. If both 'level' and 'top' are specified, 'top' is ignored.'sequential' layout: required. No option to specify 'top'. */
    level?: string,
    /** The orientation of the hierarchy layout. There are four orientations available: 'up', 'down', 'left' and 'right'. Default: 'down'. */
    orientation?: "down" | "right" | "up" | "left",
    /** How to space nodes at each level of the sequential layout. Options are 'auto', 'equal', and 'stretched'. Default: 'auto'. */
    spacing?: string,
    /** If true, curved links are straightened. If false, they remain curved. Default: true. */
    straighten?: boolean,
    /** The tidy option pushes apart the components of the chart so they don't overlap. Not used for 'organic', 'lens' or 'sequential'. Default: true. */
    tidy?: boolean,
    /** A number (0 -> 10) which controls how close the nodes should be. For 'sequential', it applies to nodes at the same level. Higher values make the nodes closer. Default: 5. */
    tightness?: number,
    /** If animated, the time the animation should take, in milliseconds. Default: 700. */
    time?: number,
    /** A node id or an array of node ids which should be at the top of the hierarchy/centre of the radial layout. 
    Required for the 'hierarchy' and 'radial' layouts, unless the level option is specified. If both 'level' and 'top' are specified, 'top' is ignored. */
    top?: string | Array<string>
  }
      
  interface LockOptions {
    /** Use if you would like a wait cursor shown while the chart is locked. */
    wait?: boolean
  }
      
  interface Band {
    /** The colour of the band. Default: light grey. */
    c?: string,
    /** Whether the band label should be displayed in bold font. Default: false. */
    fb?: boolean,
    /** The colour for the band label font. Default: light grey. */
    fc?: string,
    /** The font family to use for the band label. Default: fontFamily setting. */
    ff?: string,
    /** The font size (pt) of the band label. The band label font size may be reduced if necessary to fit the label in the band. Default: 20. */
    fs?: number,
    /** The text of the band label. */
    t?: string,
    /** The width of the band, in world coordinates. Default: 100. */
    w?: number,
    /** The position of the centre of the band along the X-axis, in world coordinates. Default: 0. */
    x?: number
  }
      
  interface ImageAlignmentOptions {
    /** Sets how far to move the icon horizontally. The value is a percentage from -50 to 50. Default: 0. */
    dx?: number,
    /** Sets how far to move the icon vertically. The value is a percentage from -50 to 50. Default: 0. */
    dy?: number,
    /** The factor by which you want to resize the icon relative to its parent. The value must be greater than 0. Default: 0. */
    e?: number
  }
      
  interface LinkEnds {
    /** Whether link ends should avoid node labels. Default: true. */
    avoidLabels?: boolean,
    /** Controls the spacing between link ends and nodes. Possible values are: 'loose' - there is a small gap between the link end and and the node.'tight' - there is no gap between the link end and the node.. Default: 'tight'. */
    spacing?: "loose" | "tight"
  }
      
  interface LinkStyleOptions {
    /** Controls the positioning of multiple glyphs on links without labels. Possible values are: 'along' - glyphs are drawn along the link.'horizontal' - glyphs are drawn horizontally.. Default: 'horizontal'. */
    glyphs?: "along" | "horizontal",
    /** Only for links with a colour gradient (c2 property set). Controls the size of the fraction at the midpoint of the link where the colour transition occurs. The value is between 0 and 1, with 0 providing an immediate transition between colours. The rest of the link is drawn with solid colours. Default: 0.75. */
    transition?: number
  }
      
  interface Bands {
    /** An array of objects defining each of the bands. */
    bands?: Array<Band>,
    /** Whether labels are displayed at the bottom of the bands. Default: false. */
    bottom?: boolean,
    /** Whether labels are displayed at the top of the bands. Default: true. */
    top?: boolean
  }
      
  interface Logo {
    /** The position of the logo. Four positions are supported - 'ne', 'se', 'sw' and 'nw'. Default: 'ne'. */
    p?: string,
    /** The URL of the logo to be displayed, or null for no logo. On Retina devices, KeyLines will also check for a double-resolution @2x version of the logo, e.g. 'path/to/images/myAwesomeLogo@2x.png' */
    u?: string,
    /** The horizontal offset in pixels from the logo's default position. Default: 0. */
    x?: number,
    /** The vertical offset in pixels from the logo's default position. Default: 0. */
    y?: number
  }
      
  interface NavigationOptions {
    /** The position of the navigation controls. Four positions are supported - 'ne', 'se', 'sw' and 'nw'. Default: 'nw'. */
    p?: "ne" | "nw" | "se" | "sw",
    /** Whether the navigation controls are displayed. Default: true. */
    shown?: boolean,
    /** The horizontal offset in pixels from the navigation controls' default position. Default: 0. */
    x?: number,
    /** The vertical offset in pixels from the navigation controls' default position. Default: 0. */
    y?: number
  }
      
  interface OverviewOptions {
    /** Whether the icon the user can click on to open/close the overview is shown. Default: true. */
    icon?: boolean,
    /** The position of the overview window. Four positions are supported - 'ne', 'se', 'sw' and 'nw'. Default: 'se'. */
    p?: string,
    /** Whether the overview window is actually shown. Default: false. */
    shown?: boolean,
    /** The size of the overview window in pixels. Default: 100. */
    size?: number
  }
      
  interface SelectedLinkOptions {
    /** The distance to back-off from end id1 as a ratio of the total length of the link line. Value in the range 0 to 1. */
    b1?: number,
    /** The distance to back-off from end id2 as a ratio of the total length of the link line. Value in the range 0 to 1. */
    b2?: number,
    /** The colour of the link line itself. */
    c?: string,
    /** If specified, the link will have a colour gradient, with colour c at the id1 end and colour c2 at the id2 end. The linkStyle transition setting controls the gradient's appearance. */
    c2?: string,
    /** Whether the label should be displayed in bold font. */
    fb?: boolean,
    /** The background colour of the font. The default is a subtle effect using white with an alpha channel. */
    fbc?: string,
    /** The colour for the label font. */
    fc?: string,
    /** The font family to use for the label. */
    ff?: string,
    /** The font size (pt) of the link label. */
    fs?: number,
    /** The style of the link line. This can be either 'solid', 'dashed' or 'dotted'. */
    ls?: "solid" | "dashed" | "dotted",
    /** The link label positioned at the id1 end. Use new lines for multiline labels. Can be one of the following options: string - Add a new label to inherit properties from the label at the centre of the link.LinkEndLabel - Use LinkEndLabel properties. */
    t1?: string | LinkEndLabel,
    /** The link label positioned at the id2 end. Use new lines for multiline labels. Can be one of the following options: string - Add a new label to inherit properties from the label at the centre of the link.LinkEndLabel - Use LinkEndLabel properties. */
    t2?: string | LinkEndLabel,
    /** The width of the link line. */
    w?: number
  }
      
  interface SelectedNodeOptions {
    /** The border colour. */
    b?: string,
    /** The style of the border line. This can be either 'solid' or 'dashed'. */
    bs?: "solid" | "dashed",
    /** The width of the node's border. */
    bw?: number,
    /** The fill colour. */
    c?: string,
    /** The enlargement factor for the node. */
    e?: number,
    /** Whether the label should be displayed in bold font. */
    fb?: boolean,
    /** The background colour of the font. The default is a subtle effect using white with an alpha channel. */
    fbc?: string,
    /** The colour for the label font. */
    fc?: string,
    /** The font family to use for the label. */
    ff?: string,
    /** The font size (pt) of the node label. */
    fs?: number,
    /** A halo object. */
    ha0?: Halo,
    /** A halo object. */
    ha1?: Halo,
    /** A halo object. */
    ha2?: Halo,
    /** A halo object. */
    ha3?: Halo,
    /** A halo object. */
    ha4?: Halo,
    /** A halo object. */
    ha5?: Halo,
    /** A halo object. */
    ha6?: Halo,
    /** A halo object. */
    ha7?: Halo,
    /** A halo object. */
    ha8?: Halo,
    /** A halo object. */
    ha9?: Halo,
    /** The style of a combo when open. */
    oc?: OpenStyleOptions,
    /** Whether resize handles should be shown. */
    re?: boolean,
    /** The URL of the node image. */
    u?: string
  }
      
  interface TruncateLabelsOptions {
    /** The maximum length labels can be before they are truncated, in characters. The labels are truncated to the length specified, the last three characters of the string are replaced with an 'ellipsis' - three dots (...). Default: 30. */
    maxLength?: number,
    /** Controls whether the full label is displayed on hover. You can change the hover interval using the hover option. Not supported on touch devices. Default: true. */
    showOnHover?: boolean
  }
      
  interface WatermarkOptions {
    /** The vertical alignment of the watermark text. 'top', 'bottom' or 'centre'. Default: 'centre'. */
    a?: "top" | "bottom" | "centre",
    /** Whether the watermark is to be shown in bold. Default: false. */
    fb?: boolean,
    /** The background colour for the watermark text. */
    fbc?: string,
    /** The colour of the watermark text. */
    fc?: string,
    /** The font family to use. If not specified uses fontFamily above. */
    ff?: string,
    /** The watermark's font size (pt). Default: 80. */
    fs?: number,
    /** The text of the watermark. */
    t?: string,
    /** The URL of the watermark if an image is to be shown. */
    u?: string
  }
      
  interface Gradient {
    /** Defines the gradient colours as an array. */
    stops?: Array<GradientColour>
  }
      
  interface GradientColour {
    /** The r (ratio) values are the proportion from top to bottom. */
    r?: number,
    /** The c is the colour setting for that stop. */
    c?: string
  }
      
  interface ComboLinkStyle {
    /** The distance to back-off from end id1 as a ratio of the total length of the link line. Value in the range 0 to 1. */
    b1?: number,
    /** The distance to back-off from end id2 as a ratio of the total length of the link line. Value in the range 0 to 1. */
    b2?: number,
    /** The colour of the link line itself. */
    c?: string,
    /** The style of the link line. This can be either 'solid', 'dashed' or 'dotted'. */
    ls?: "solid" | "dashed" | "dotted",
    /** The width of the link line. If the link has arrows, this width will affect the size of the arrowheads. */
    w?: number
  }
      
  interface StyleOptions {
    /** Sets the style of the glyph. Glyphs are only shown on closed combos. The default is red in the top right corner showing the number of nodes contained within the combo. Set to null for no glyph. */
    comboGlyph?: Glyph,
    /** Settings for the style of combo links created through using combine, or by adding new links. Any properties not specified will be copied from a link that the combo link contains. */
    comboLinks?: ComboLinkStyle,
    /** Settings for the open style of combos. The default is a light grey background with a grey border. */
    openCombos?: OpenStyleOptions
  }
      
  interface ChartOptions {
    /** Controls the appearance of arrows on links. Possible values are 'small', 'normal', 'large' and 'xlarge'. Arrowhead size is also proportional to the link width ('w'). Default: 'normal'. */
    arrows?: "normal" | "small" | "large" | "xlarge",
    /** The colour to use for the background of the chart itself. Default: 'white'. */
    backColour?: string,
    /** The alpha value to apply to background items, in the range 0 to 1. */
    backgroundAlpha?: number,
    /** Set to give the chart a set of labelled vertical background bands */
    bands?: Bands,
    /** The rgb colour to use for the navigation and overview window controls. 
    Only the hue and saturation of the colour are used: the lightness is fixed. */
    controlColour?: string,
    /** Settings to control the default style of certain chart objects */
    defaultStyles?: StyleOptions,
    /** If true, drag operations will pan the chart automatically
    if the mouse or touch position moves near the edge of or outside the chart area.
    If false, the chart will not pan if the mouse or touch position moves near the
    edge of the chart area during a drag operation, and the drag will be cancelled
    if the mouse moves outside the chart area. Default: true. */
    dragPan?: boolean,
    /** The default font family to use, for example 'sans-serif' or 'helvetica'.
    If you don’t set a font family, 'sans-serif' is used.
    If you set multiple font families, only the first one supported by the browser is used. Default: 'sans-serif'. */
    fontFamily?: string,
    /** Set to give the chart a background gradient fill that runs from top to bottom of the chart */
    gradient?: Gradient,
    /** If true, dragging the chart background drags all items. 
    If false, dragging the chart background draws a bounding box for selecting items. Default: false. */
    handMode?: boolean,
    /** The number of milliseconds delay before the hover event is triggered. Default: 150. */
    hover?: number,
    /** The default font family to use for font icons, for example 'FontAwesome' or 'Octicons'.
    If not set, the font family 'sans-serif' is used.
    If you set multiple font families, only the first one supported by the browser is used. Default: 'sans-serif'. */
    iconFontFamily?: string,
    /** For each image path or font icon, set the position and scale. 
    The imageAlignment should contain a property with the path of the image or the font icon which is to be adjusted. */
    imageAlignment?: IdMap<ImageAlignmentOptions>,
    /** An integer to move the label text up or down. Useful only for certain fonts where the baseline is irregular (e.g. Open Sans). */
    labelOffset?: number,
    /** Contains settings that control how the ends of links are drawn. */
    linkEnds?: LinkEnds,
    /** Settings to control how links are drawn. */
    linkStyle?: LinkStyleOptions,
    /** Settings for the logo to be displayed in a corner of the chart */
    logo?: Logo,
    /** Controls how links are selected when dragging a selection marquee. Possible values are: 'centre', 'ends' or 'off'. Default: 'centre'. */
    marqueeLinkSelection?: "centre" | "ends" | "off",
    /** Sets the maximum zoom for items, from minZoom to 4. We suggest a value of around 1 to have an optimal result. */
    maxItemZoom?: number,
    /** Sets the minimum zoom for the view.
    Use a smaller value to allow the chart to be zoomed out further.
    The value can be from 0.001 to 1. Default: 0.05. */
    minZoom?: number,
    /** An object whose properties are the settings for the navigation controls */
    navigation?: NavigationOptions,
    /** An object whose properties are the settings for the overview window. */
    overview?: OverviewOptions,
    /** Specifies how to draw selected links. If present, its value is an object whose
    properties override the properties of selected links when they are drawn. If null or undefined, selected links are drawn with a circle in the colour specified by the selectionColour chart option. */
    selectedLink?: SelectedLinkOptions,
    /** Specifies how to draw selected nodes. If present, its value is an object whose
    properties override the properties of selected nodes when they are drawn. If null or undefined, selected nodes are drawn with a border in the colour specified by the selectionColour chart option. */
    selectedNode?: SelectedNodeOptions,
    /** The default colour to use for items selected on the chart. Default: 'rgb(114, 179, 0)'. */
    selectionColour?: string,
    /** The default font colour to use for items selected on the chart. Default: 'rgb(255, 255, 255)'. */
    selectionFontColour?: string,
    /** If true, links from a node to itself can be added to the chart. If false, such links are ignored. Default: false. */
    selfLinks?: boolean,
    /** If specified, an object whose properties control how item labels are truncated. If not specified, item labels are not truncated. */
    truncateLabels?: TruncateLabelsOptions,
    /** An object whose properties are the settings for the watermark in the centre of the chart */
    watermark?: WatermarkOptions
  }
      
  interface PanOptions {
    /** Whether the transition should be animated. Default: false. */
    animate?: boolean,
    /** The length of the animation in milliseconds. Default: 1000. */
    time?: number
  }
      
  interface PingOptions {
    /** The rgb colour to use for the animated effect. Default: 'mid-grey'. */
    c?: string,
    /** The maximum width of the links' animated effect. Default: 40. */
    lw?: number,
    /** The radius of the nodes' halo at the end of the animation. Default: 80. */
    r?: number,
    /** The number of times the animation should be repeated. Default: 1. */
    repeat?: number,
    /** The time the animation should take, in milliseconds. Default: 800. */
    time?: number,
    /** The width of the nodes' halo at the end of the animation. Default: 20. */
    w?: number
  }
      
  interface ShowOptions {
    /** Whether the transition should be animated. Default: false. */
    animate?: boolean,
    /** The length of the animation in milliseconds. Default: 1000. */
    time?: number
  }
      
  interface ToDataURLOptions {
    /** How the current view settings are mapped when generating the image. This can be one of four values: 'exact', 'view', 'chart' or 'oneToOne'. Default: 'exact'. */
    fit?: "exact" | "view" | "chart" | "oneToOne",
    /** Whether the chart background gradient (if any) should be drawn. Default: true. */
    gradient?: boolean,
    /** Whether the logo (if any) should be drawn. Default: true. */
    logo?: boolean,
    /** If noScale is true, the image is drawn as if it were a new component at 1-1 scale. 
     This means that any logo or watermark will be drawn at 1-1 in the image. If false, the logo and watermark are sized to fit the image size. Default: false. */
    noScale?: boolean,
    /** Whether the current selection (if any) should be drawn selected in the image. Default: false. */
    selection?: boolean,
    /** Whether the watermark (if any) should be drawn. Default: true. */
    watermark?: boolean
  }
      
  interface Transition {
    /** Whether the transition should be animated. Default: false. */
    animate?: boolean,
    /**  The time the animation should take, in milliseconds. Default: 1000. */
    time?: number
  }
      
  interface ViewOptions {
    /** The level of zoom. 1 is 1-to-1. Note that you cannot use the zoom option in map mode. For details on controlling zoom in map mode see the Map Mode documentation. Default: 1. */
    zoom?: number,
    /** The view offset in the X direction measured in pixels. Default: 0. */
    offsetX?: number,
    /** The view offset in the Y direction measured in pixels. Default: 0. */
    offsetY?: number,
    /** The height of the view (read only). */
    height?: number,
    /** The width of the view (read only). */
    width?: number
  }
      
  interface Coordinates {
    /** The x coordinate */
    x: number,
    /** The y coordinate */
    y: number
  }
      
  interface ZoomOptions {
    /** Whether the transition should be animated. Default: false. */
    animate?: boolean,
    /** The length of the animation in milliseconds. Default: 1000. */
    time?: number,
    /** The id or array of ids to zoom to in 'fit' or 'height' mode. If no ids are specified 'fit' will fit the chart to the window, 'height' will fit the chart height to the window. */
    ids?: string | Array<string>
  }

  interface ComboArrangeOptions {
    /** Whether the operation should be animated. Default: true. */
    animate?: boolean,
    /** Controls how nodes are arranged inside an open combo. Possible values are: 'lens' - items are arranged automatically with connected nodes next to each other.'concentric' - items are arranged automatically inside a circle with larger items at the centre.'none' - items are kept in their original positions.. Default: lens. */
    name?: "lens" | "concentric" | "none",
    /** If true, the open combos will be resized to fit their contents. If false, they will not be resized, unless the contents are beyond the current boundary. Default: true. */
    resize?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 250. */
    time?: number
  }
      
  interface CloseOptions {
    /** Whether the operation should be animated. Default: true. */
    animate?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 250. */
    time?: number
  }
      
  interface ComboDefinition {
    /** If defined, all properties will be transferred to the new combo's d property. */
    d?: any,
    /** An x offset for positions of members of the combo if it is later uncombined. Default: 0. */
    dx?: number,
    /** A y offset for positions of members of the combo if it is later uncombined. Default: 0. */
    dy?: number,
    /** An array of id strings of nodes to combine. This can contain one or more node ids. */
    ids: string | Array<string>,
    /** The style of glyph to create. Glyphs are only shown on closed combos. The default is red in the top right corner showing the number of nodes contained within the combo. Set to null for no glyph. You can add more glyphs using "style.g". */
    glyph?: Glyph,
    /** The label to use for the combo. If unspecified, a label will be generated from the 't' properties of the combo's child nodes. */
    label?: string,
    /** The style of the closed combo node using the standard node property names. If not specified, the style will be the same as the first node in the ids array. If style.hi is not specified, the combo will be visible if any of its member nodes are visible. */
    style?: NodeStyle,
    /** The style of the open combo node using the standard node property names. If not specified, the style will be set to the open combo style from defaultStyles. */
    openStyle?: OpenStyleOptions,
    /** Whether the combo should be created in the open state. Default: false. */
    open?: boolean,
    /** The chart position of the final combo. Possible values are:  'average' - use the average position of the nodes to centre the arrangement.'first' - use the position of the first node in the ids array.. Default: 'average'. */
    position?: "average" | "first"
  }
      
  interface CombineOptions {
    /** Whether the combination(s) should be animated. Default: true. */
    animate?: boolean,
    /** Controls how nodes are arranged inside an open combo. Possible values are: 'lens' - items are arranged automatically with connected nodes next to each other.'concentric' - items are arranged inside a circle with larger items at the centre.'none' - items are kept in their original positions.. Default: lens. */
    arrange?: "lens" | "concentric" | "none",
    /** Whether the combo(s) should be selected. Default: true. */
    select?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 250. */
    time?: number
  }
      
  interface ComboFindOptions {
    /** There's a parent/child relationship between a combo and the items it contains. The parent can be one of two values: 'first': finds the immediate parent of the item.'top': finds the parent at the top of the nested combo hierarchy.. Default: 'top'. */
    parent?: "top" | "first"
  }
      
  interface IsComboOptions {
    /** Specifies which types of item are tested: either 'all', 'node', or 'link'. Default: 'all'. */
    type?: "node" | "link" | "all"
  }
      
  interface OpenOptions {
    /** Whether the operation should be animated. Default: true. */
    animate?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 250. */
    time?: number
  }
      
  interface TransferOptions {
    /** Whether the transfer operation should be animated. Default: true. */
    animate?: boolean,
    /** Controls how nodes are arranged inside source and destination open combos. Possible values are: 'lens' - items are arranged automatically with connected nodes next to each other.'concentric' - items are arranged inside a circle with larger items at the centre.'none' - items are kept in their original positions.. Default: lens. */
    arrange?: "lens" | "concentric" | "none",
    /** If true, the open combos will be resized to fit their contents. If false, they will not be resized, unless the contents are beyond the current boundary. Default: true. */
    resize?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 250. */
    time?: number
  }
      
  interface UncombineOptions {
    /** Whether the operation should be animated. Default: true. */
    animate?: boolean,
    /** Whether all nodes inside the combo (including nodes inside nested combos) should be uncombined. If false, just the first level of the combo is uncombined. Default: false. */
    full?: boolean,
    /** Whether the uncombined nodes should be selected. Default: true. */
    select?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 250. */
    time?: number
  }
    
  interface MapOptions {
    /** Whether showing and hiding the map should be animated. Default: true. */
    animate?: boolean,
    /** Pass options directly into the Leaflet constructor. */
    leaflet?: any,
    /** Specifies how much space, in pixels, to leave around the map when zooming to fit. Default: 5. */
    padding?: number,
    /** A string specifying the url template for map tiles, in the form 'https://example.com/path/{z}/{x}/{y}.png', or an object in the Leaflet TileLayer options format, with an additional 'url' property specifying the url template. If set to null, the tiles layer will not be created. */
    tiles?: any | string,
    /** If animated, the time that showing or hiding the map should take, in milliseconds. Default: 800. */
    time?: number,
    /** Controls how items are positioned when transitioning from map mode to network mode. Use 'restore' to move items back to their previous positions, or 'layout' to position using a 'standard' layout. Default: 'restore'. */
    transition?: 'restore' | 'layout'
  }
    
  interface BetweennessOptions {
    /** Whether the betweenness computation should consider the direction of links. Default: false. */
    directed?: boolean,
    /** This defines if the betweenness measure should be normalized by component, 
    by chart or not normalized. Values are - 'unnormalized', 'chart' and 'component'. . Default: 'component'. */
    normalization?: "unnormalized" | "chart" | "component",
    /** The name of the custom property which defines each link's length. Custom properties mean properties set on the 'd' property of the links. */
    value?: string,
    /** If true, the path length of any link is the reciprocal of the value ( 1 / value ). Default: false. */
    weights?: boolean,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface ClosenessOptions {
    /** 'from', 'to', or 'any'. 'from' only includes links in the direction of arrows, 'to' only includes links against the direction of arrows, and 'any' includes any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links. Default: 'any'. */
    direction?: "from" | "to" | "any",
    /** This defines if the closeness measure should be normalized by component or by chart. Allowed values are 'chart' or 'component'. Default: 'component'. */
    normalization?: "chart" | "component",
    /** The name of the custom property which defines each link's value. Custom properties mean properties set on the 'd' property of the links. */
    value?: string,
    /** This option means that the path length of any link is the reciprocal of the value, i.e. ( 1 / value ). Default: false. */
    weights?: boolean,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface ClustersOptions {
    /** The name of a custom property which defines each link's value. Custom properties mean properties set on the 'd' property of the links. Higher valued links tend to cluster their nodes more closely. */
    value?: string,
    /** A number from 0 to 10 that affects cluster size. Higher values give smaller clusters, but more of them; lower values give larger clusters, but not as many. Default: 5. */
    factor?: number,
    /** Set to true to see the same result every time you run a cluster, or false if you want to see different results. Default: true. */
    consistent?: boolean,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface ComponentsResult {
    /** Array of node ids in this component */
    nodes: Array<string>,
    /** Array of link ids in this component */
    links?: Array<string>
  }
      
  interface ComponentsOptions {
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface DegreesOptions {
    /** 'from', 'to', or 'any'. 'from' counts only links with arrows pointing away from nodes (out-degree), 'to' counts only links with arrows pointing to nodes (in-degree), and 'any' counts all links regardless of whether they have arrows. Note that to use 'from' or 'to', your graph must have arrows on links. Default: 'any'. */
    direction?: "from" | "to" | "any",
    /** The name of the custom property which defines each link's value. Custom properties mean properties set on the 'd' property of the links. */
    value?: string,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface DistancesOptions {
    /** 'from', 'to', or 'any'. 'from' only includes links in the direction of arrows, 'to' only includes links against the direction of arrows, and 'any' includes any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links. Default: 'any'. */
    direction?: "from" | "to" | "any",
    /** The name of the custom property which defines the distance value of a link. Custom properties mean properties set on the 'd' property of the links. */
    value?: string,
    /** This option means that the path length of any link is the reciprocal of the value, i.e. ( 1 / value ). Default: false. */
    weights?: boolean,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface EigenCentralityOptions {
    /** The name of the custom property which defines the value of a link. Custom properties mean properties set on the 'd' property of the links. If not set, all links have value 1. */
    value?: string,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface KCoresResult {
    /** The maximum k in the graph. */
    maximumK?: number,
    /** A dictionary of all nodes, each one with its k value. */
    values?: IdMap<number>
  }
      
  interface KCoresOptions {
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface NeighboursResult {
    /** Array of neighbouring node ids */
    nodes: Array<string>,
    /** Array of neighbouring link ids */
    links?: Array<string>
  }
      
  interface NeighboursOptions {
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean,
    /** 'from', 'to', or 'any'. 'from' only finds neighbours in the direction of arrows, 'to' only finds neighbours against the direction of arrows, and 'any' finds neighbours on any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links. Default: 'any'. */
    direction?: "from" | "to" | "any",
    /** This defines how far away neighbours can be from the passed ids. Default: 1. */
    hops?: number
  }
      
  interface PageRankOptions {
    /** The name of the custom property which defines the value of a link. Custom properties mean properties set on the 'd' property of the links. If not set, all links have value 1. */
    value?: string,
    /** If false, all the links are treated as undirected for the PageRank computation. Default: true. */
    directed?: boolean,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }
      
  interface ShortestPathsResult {
    /** One of the shortest paths found - returned as an array of alternating node and link ids, including the start and end nodes */
    onePath: Array<string>,
    /** An array describing the same path as onePath, but containing node ids only, including the start and end nodes */
    one: Array<string>,
    /** An array of all node and link ids that are on all the shortest paths, including the start and end nodes  */
    items: Array<string>,
    /** The length of the shortest path - more precisely the combined link value of the path */
    distance: number
  }
      
  interface ShortestPathsOptions {
    /** 'from', 'to', or 'any'. 'from' only traverses links in the direction of arrows, 'to' only traverses links against the direction of arrows, and 'any' can traverse any link regardless of arrows. Note that to use 'from' or 'to', your graph must have arrows on links. Default: 'any'. */
    direction?: "from" | "to" | "any",
    /** The name of the custom property which defines the value of a link. Custom properties mean properties set on the 'd' property of the links. */
    value?: string,
    /** This option means that the path length of any link is the reciprocal of the value, i.e. ( 1 / value ). Default: false. */
    weights?: boolean,
    /** This option lets the function iterate on all nodes and links in the chart when true, hidden ones included. Default: false. */
    all?: boolean
  }

  interface Component {
    /** The DOM element or id where you want to insert the component. */
    container?: string | HTMLElement,
    /** The id of component.  If not specified, one will automatically be assigned. */
    id?: string,
    /** @deprecated The DOM element that you want to replace with the component. For more information see The KeyLines container. */
    element?: HTMLElement,
    /** The type of component to create, either 'chart' or 'timebar'. Default: chart. */
    type?: "chart" | "timebar",
    /** The chart or time bar options for the new component (optional). */
    options?: ChartOptions | TimeBarOptions
  }
      
  interface GraphEngineOptions {
    /** If true, links from a node to itself can be loaded into the graph engine. If false, such links are ignored. Default: false. */
    selfLinks?: boolean
  }
      
  interface PathsOptions {
    /** @deprecated Not used. */
    assets?: string,
    /** The path to use for images (optional). */
    images?: string
  }

  interface DragControlOptions {
    /** whether dragging is allowed in the x-direction. Default: true. */
    x?: boolean,
    /** whether dragging is allowed in the y-direction. Default: true. */
    y?: boolean,
    /** an array of ids of items that will also be dragged, even if they are not selected. Applies to the 'move' dragger only. */
    add?: Array<string>,
    /** whether dragging nodes in combos also drags the combos. Applies to the 'move' dragger only. Default: true. */
    combos?: boolean
  }
 
  interface Locale {
    /** An array of two strings giving the text to use for AM and PM when displaying 12-hour clock times. Optionally this array may contain two more strings, which are used to label time bar intervals representing the first and second halves of days. Default: ['AM', 'PM']. */
    ampm?: Array<string>,
    /** A flag indicating whether the 12-hour clock should be used to display times. If false, the 24-hour clock is used. Default: true. */
    h12?: boolean,
    /** A prefix used to indicate halves of years. Default: 'H'. */
    half?: string,
    /** An array of strings giving the full names of the months, starting with January. Default: ['January', etc]. */
    longMonths?: Array<string>,
    /** A string controlling the order of dates. Supported values are 'dmy' for day-month-year, and 'mdy' for month-day-year. Default: 'mdy'. */
    order?: string,
    /** A prefix used to indicate quarters of years. Default: 'Q'. */
    quarter?: string,
    /** An array of strings giving abbreviated names of the months, starting with January. Default: ['Jan', etc]. */
    shortMonths?: Array<string>
  }
      
  interface HeightChange {
    /** Whether height changes should be animated. Default: true. */
    animate?: boolean,
    /** If animated, the time the animation should take, in milliseconds. Default: 200. */
    time?: number
  }
      
  interface Histogram {
    /** The colour of the histogram bars. Default: light grey. */
    colour?: string,
    /** The colour of the histogram bars when they are hovered over. Default: grey. */
    highlightColour?: string,
    /** The colour of histogram bars which contain marked times. Default: light red. */
    markColour?: string,
    /** The colour of the marked histogram bars when they are hovered over. Default: red. */
    markHiColour?: string
  }
      
  interface MaxRange {
    /** The number of the specified units. */
    value?: number,
    /** The unit of the maximum range. The supported units are: 'year', 'month', 'week', 'day', 'hour', 'min' and 'sec'. */
    units?: string
  }
      
  interface MinScale {
    /** The number of the specified units. Default: 1. */
    value?: number,
    /** The unit of the minimum scale level. The supported units are: 'year', 'month', 'week', 'day', 'hour', 'min' and 'sec'. Default: 'sec'. */
    units?: string
  }
      
  interface Scale {
    /** The colour of the time scale section that is hovered over. Default: light grey. */
    highlightColour?: string,
    /** Whether the major time scale (the lower scale) is shown. Default: true. */
    showMajor?: boolean,
    /** Whether the minor time scale (the higher scale) is shown. Default: true. */
    showMinor?: boolean
  }
      
  interface TimeBarOptions {
    /** The colour to use for the background of the time bar. Default: white. */
    backColour?: string,
    /** The colour to set the font of the time bar (used in the scales). Default: grey. */
    fontColour?: string,
    /** The font family to use, for example, 'sans-serif'. If you don’t set a font family, 'sans-serif' is used. If you set multiple font families, only the first one supported by the browser is used. */
    fontFamily?: string,
    /** The font size to use. There is no size limit, but most fonts look better if you use a value between 7 and 13. Default: 12. */
    fontSize?: number,
    /** Options controlling animation of height changes for histogram bars and selection lines. */
    heightChange?: HeightChange,
    /** Options for the histogram bars. */
    histogram?: Histogram,
    /** Specifies how dates and times are displayed. */
    locale?: Locale,
    /** Specifies the time range at the time bar's maximum zoom level, for example with a maxRange fixed to { units: 'hour', value: 6 } the time bar will not zoom out beyond six-hour intervals. This is useful if your dataset spans a large time range and you want to limit the amount of data visible.For the 'auto' default, KeyLines calculates the range between the data's earliest and latest dates/times and multiplies it by two.. Default: 'auto'. */
    maxRange?: string | MaxRange,
    /** Specifies the time interval at the time bar's minimum scale level, for example with a minScale fixed to { units: 'hour', value: 6 } the time bar will not zoom in beyond six-hour intervals. This can be useful when the data has no precise information about the hour or the minute of the event to stop zooming further. */
    minScale?: MinScale,
    /** The speed that the time bar moves at when playing, in pixels per second.
    May be negative to animate backwards in time in 'normal' mode, or to animate the right hand slider moving backwards in time in 'extend' mode. Default: 60. */
    playSpeed?: number,
    /** Options for the minor and major time scales. */
    scale?: Scale,
    /** Whether the control bar at the base of the time bar is shown. Default: true. */
    showControlBar?: boolean,
    /** Whether the extend button is displayed. Default: false. */
    showExtend?: boolean,
    /** Whether the fit button is displayed. Default: true. */
    showFit?: boolean,
    /** Whether the play button is displayed. Default: true. */
    showPlay?: boolean,
    /** The colour to set the slider. The default is white with an opacity of 0.6. */
    sliderColour?: string,
    /** The colour to set the bars at the inner edge of the slider. Default: grey. */
    sliderLineColour?: string,
    /** Specifies slider behaviour. Options are 'fixed', 'free' or 'none'. Default: 'fixed'. */
    sliders?: "fixed" | "free" | "none"
  }
      
  interface TimeBarPanOptions {
    /** Whether the transition should be animated. Default: true. */
    animate?: boolean,
    /** The length of the animation in milliseconds. Default: 200. */
    time?: number
  }
      
  interface TimeBarPlayOptions {
    /** If true, the start of the range stays fixed and the end is extended. Default: false. */
    extend?: boolean
  }
      
  interface TimeBarRangeResult {
    /** The start time for the time range of the time bar, as a Date object */
    dt1: Date,
    /** The end time for the time range of the time bar, as a Date object */
    dt2: Date
  }
      
  interface TimeBarRangeOptions {
    /** Whether the transition should be animated. Default: true. */
    animate?: boolean,
    /** The length of the animation in milliseconds. Default: 200. */
    time?: number
  }
      
  interface SelectionOptions {
    /** An id or a list of ids to select. */
    id?: string | Array<string>,
    /** The index for the selection line. This field can be omitted when a single selection is passed. */
    index?: number,
    /** The colour for the selection line. */
    c?: string
  }
      
  interface TimeBarZoomOptions {
    /** Whether the transition should be animated. Default: true. */
    animate?: boolean,
    /** For 'fit' only: the id string or array of id strings of items to include in the fit range. If not specified, all items are included. */
    id?: string | Array<string>,
    /** The length of the animation in milliseconds. Default: 200. */
    time?: number
  }

  interface Chart {
    /** animateProperties allows custom animations to be made and chained together.
    * @param items An array of items whose properties are to be changed, or an object if just one item is changing.
    * @param options Options to control the animation.*/
    animateProperties(items: NodeProperties | LinkProperties | ShapeProperties | Array<NodeProperties | LinkProperties | ShapeProperties>, options?: AnimatePropertiesOptions): Promise<void>;
        
    /**  The arrange function places a set of nodes together in close proximity to each other.
    * @param name The arrangement to use: 'grid', 'circle' or 'radial'.
    * @param items An array of the ids of the nodes to arrange.
    * @param options Various options to control the arrangement of the nodes*/
    arrange(name: "grid" | "circle" | "radial", items: Array<string>, options?: ArrangeOptions): Promise<void>;
        
    /** Clear removes all items from the chart.*/
    clear(): void;
        
    /** The combo namespace has methods for combining the nodes and links of a chart to simplify it.*/
    combo(): Combo;
        
    /** The contains function returns an array of ids of all the nodes contained inside the given shape.
    * @param shape The definition of the shape.
    * @returns The ids of the nodes contained in the shape (if any)*/
    contains(shape: ShapeOptions): Array<string>;
        
    /** The createLink function allows the user to draw a new link starting from a specified node.
    * @param id The id of the starting node; this node will be the id1 of the new link.
    * @param linkId The id to set on the new link.
    * @param options Various options to control the style of the link.
    * @returns The id of the linked item, or null if the user did not create a link.*/
    createLink(id: string, linkId: string, options?: CreateLinkOptions): Promise<string>;
        
    /** Destroys the current instance of the chart, freeing any allocated resources.*/
    destroy(): void;
        
    /** The each function allows easy iteration over all the items in the chart. The handler is called with one parameter: the current item.
    * @param options Options controlling how to iterate over the chart items.
    * @param handler The function to be called for each item in the chart.*/
    each(options: EachOptions, handler: Function): void;
        
    /** The expand function is the easiest way to add new items to the chart. It performs a merge followed by a layout.
    * @param items A KeyLines chart object or an array of items to be added.
    * @param options Various options to control the expanding action of the nodes.*/
    expand(items: ChartData | Array<Node | Link | Shape>, options?: ExpandOptions): Promise<void>;
        
    /** The filter function allows items in the chart to be hidden or shown depending on your own criterion.
    * @param filterFn A function which takes an item as argument. Returns true if the item should be visible, false otherwise.
    * @param options Various options to control the filtering.
    * @returns A Promise.*/
    filter(filterFn: Function, options?: FilterOptions): Promise<FilterResult>;
        
    /** The foreground function allows items in the chart to be set as background or foreground items depending on your own criterion.
    * @param foregroundFn A function which takes an item as its argument, returning false if the item should be in the background, true otherwise.
    * @param options Various options to control the foreground operation.
    * @returns A Object which contains the nodes and links which are in the foreground and background */
    foreground(foregroundFn: Function, options?: ForegroundOptions): Promise<ForegroundResult>;
        
    /** Returns a copy of the items in the chart which match the id. To update the items, use chart.setProperties().
    * @param id The id string of the item to be retrieved.
    * @returns The item matched. Returns null if there is no item matching an id.*/
    getItem(id: string): Node | Link | Shape;
        
    /** Returns a copy of the items in the chart which match the id. To update the items, use chart.setProperties().
    * @param ids The array of id strings of the items to be retrieved.
    * @returns The items matched. Returns null if there is no item matching an id.*/
    getItem(ids: Array<string>): Array<Node | Link | Shape>;
        
    /** The graph object has methods for navigating the graph structure (the nodes and links) of a chart.*/
    graph(): Graph;
        
    /** Hide item or items with the id(s) specified. Pass a single id to hide a single item, or an array of id strings to hide many items at once.
    * @param id The id string or array of id strings of items to hide.
    * @param options Options controlling the hide operation*/
    hide(id: string | Array<string>, options?: HideOptions): Promise<void>;
        
    /** labelPosition returns information about the label by the item with the id specified. This function does not return the label position for 't1' or 't2' labels.
    * @param id The identity of the item.
    * @returns An object containing label coordinate properties: {x1: (left), x2: (right), y1: (top), y2: (bottom), fs: (font size at current zoom)}.*/
    labelPosition(id: string): LabelPosition;
        
    /** The layout function positions the nodes of the chart.
    * @param name The name of the layout to be invoked. The default is 'standard'.
    * @param options Sets various features of the layout*/
    layout(name?: "standard" | "organic" | "hierarchy" | "sequential" | "lens" | "radial" | "structural" | "tweak", options?: LayoutOptions): Promise<void>;
        
    /** Replaces the chart data with the new data specified. Any existing objects in the chart will be dereferenced.
    * @param data The data to load into the chart*/
    load(data: ChartData): Promise<void>;
        
    /** The chart has a lock state. When locked, no end-user interactions are possible: no mouse, keyboard or touch events will alter the state of the chart.
    * @param val If specified, sets the chart lock state. 
    * @param options Use {wait: true} if you would like a wait cursor shown while the chart is locked
    * @returns True if the chart is locked, false otherwise.*/
    lock(val?: boolean, options?: LockOptions): boolean;
        
    /** The map namespace has methods for displaying the chart on a map.*/
    map(): Map;
        
    /** Adds new items to the chart, or modifies the properties of existing items on the chart. 
    * @param items A KeyLines chart object or an array of items to be added.*/
    merge(items: Node | Link | Shape | ChartData | Array<Node | Link | Shape>): Promise<void>;
        
    /** The options function sets the current chart display and interaction options.
    * @param ChartOptions Sets the chart options    
    * @returns The current options*/
    options(ChartOptions: ChartOptions): Promise<void>;
        
    /** The options function gets the current chart display and interaction options.*/
    options(): ChartOptions;
        
    /** Pan the chart in the direction specified
    * @param direction Which direction to pan.
    * @param options Options controlling the pan operation.*/
    pan(direction: "up" | "down" | "left" | "right" | "selection", options?: PanOptions): Promise<void>;
        
    /** The ping function adds an animated effect to a specified item, animates it, and then removes it again.
    * @param id The id string or array of id strings of items to be animated.
    * @param options Options to control the animation*/
    ping(id: string | Array<string>, options?: PingOptions): Promise<void>;
        
    /** Remove item or items with the id(s) specified. Pass a single id to remove a single item, or an array of id strings to remove many items at once.
    * @param id The id string or array of id strings of items to remove.*/
    removeItem(id: string | Array<string>): void;
        
    /** The selection function sets the current chart selection as an array of ids.
    * @param val Sets the chart selection. The array should be ids of the items to select. 
    * @returns The current selection as a list of item ids.*/
    selection(val: Array<string>): Array<string>;
        
    /** The selection function gets the current chart selection as an array of ids.*/
    selection(): Array<string>;
        
    /** The serialize function returns a complete serialization of the current chart content in the form specified by the object properties section. This can be used for saving the chart state in a database or for implementing features like undo or redo. Note: We don't recommend parsing the results of chart.serialize as a way to get items. Use chart.each instead.*/
    serialize(): ChartData & TimeBarData;
        
    /** Sets the location in the DOM of the chart on the page.  Set this to null to temporarily remove it. You must specify the container parameter in KeyLines.create to use setContainer.
    * @param element The id string or DOM element of the parent container that the chart should append to.*/
    setContainer(element?: string | HTMLElement): void;
        
    /** setItem creates a new item in the chart with the specified properties.
    * @param item The item object to set in the chart
    * @returns A Promise*/
    setItem(item: Node | Link | Shape): Promise<void>;
        
    /** setProperties is a powerful function for changing the properties of many items at once.
    * @param items An array of items whose properties are to be changed.
    * @param useRegEx Whether the ids are to be treated as regular expression strings. The default is false.*/
    setProperties(items: NodeProperties | LinkProperties | ShapeProperties | Array<NodeProperties | LinkProperties | ShapeProperties>, useRegEx?: boolean): Promise<void>;
        
    /** Shows (unhides) the items specified by the id parameter
    * @param id The id string or array of id strings of items to show.
    * @param showLinks If true then any hidden links to nodes which will become shown are also shown.
    * @param options Options controlling the show operation.*/
    show(id: string | Array<string>, showLinks?: boolean, options?: ShowOptions): Promise<void>;
        
    /** This function returns a data URL of the chart image
    * @param width The width of the required image in pixels. The default is the width of the chart element. Not supported in map mode.
    * @param height The height of the required image in pixels. The default is the height of the chart element. Not supported in map mode.
    * @param options Various options which control how the image is created
    * @returns A base64 encoded PNG image string*/
    toDataURL(width?: number, height?: number, options?: ToDataURLOptions): Promise<string>;
        
    /** The unbind function detaches an event handler that was attached to it
    * @param name The name of the event to be detached from, e.g., 'click'. You can also unbind multiple events in a single call, separating each one with a comma or space, e.g. 'click, touchdown'.
    * @param handler The event handler that was supplied to the bind call.*/
    unbind(name?: string, handler?: Function): void;
        
    /** viewCoordinates is a function for converting world coordinates - positions of items within the chart - to screen coordinates in the current view. This depends on the current view settings (zoom and pan). View coordinates are relative to the top left corner of the chart.
    * @param x The x position in world coordinates.
    * @param y The y position in world coordinates.
    * @returns An object {x: x, y: y} containing the view coordinates    */
    viewCoordinates(x: number, y: number): Coordinates;
        
    /** The viewOptions function sets the current chart view options, which covers the zoom setting and viewport location.
    * @param viewOptions Sets the view options   
    * @param transition How the transition should be managed       
    * @returns The current view options*/
    viewOptions(viewOptions: ViewOptions, transition?: Transition): Promise<void>;
        
    /** The viewOptions function gets the current chart view options, which covers the zoom setting and viewport location.*/
    viewOptions(): ViewOptions;
        
    /** worldCoordinates is a function for converting screen coordinates (in the current view) to the coordinates which are used to represent the position of items within the chart. This depends on the current view settings (zoom and pan).
    * @param x The position in screen pixel coordinates relative to the left side of the chart.
    * @param y The position in screen pixel coordinates relative to the top of the chart.
    * @returns An object {x: x, y: y} containing the world coordinates    */
    worldCoordinates(x: number, y: number): Coordinates;
        
    /** Zoom the chart in the manner specified.
    * @param how How to zoom the chart: 'in', 'out', 'one', 'fit' (fit chart or specified ids to window), 'height' (fit chart height or height of specified ids to window) or 'selection' (fit selection to window).
    * @param options Options controlling the zoom operation*/
    zoom(how: "in" | "out" | "one" | "fit" | "height" | "selection", options?: ZoomOptions): Promise<void>;
  
    /** Binding to the all event will capture all events that occur within the KeyLines chart. It is slightly different in structure to other events in that the first argument is the name of the event which was captured. The rest of the arguments depend on the type of event captured. Return true to override the event's default action
    * @param name The name of the event which was captured, e.g. 'click'.*/
    bind(name: 'all', handler: (name?: string) => boolean): void;
        
    /** The click event is triggered when the end-user clicks on the chart surface. On touch devices this is triggered when the end-user touches the chart.
    * @param id The id of the item that was clicked, or null if the mouse was on the chart background.
    * @param x The x location of the click in view coordinates.
    * @param y The y location of the click in view coordinates.
    * @param button The button used. 0 is logical left button and 1 is middle. To trap the right-click use the context menu event.
    * @param sub The sub-widget clicked, or null if the click is over the main part of the item.*/
    bind(name: 'click', handler: (id?: string, x?: number, y?: number, button?: number, sub?: string) => void): void;
        
    /** The contextmenu event is triggered when the end-user right-clicks on the chart surface. On touch devices this is triggered when the end-user does a long press on the chart.
    * @param id The id of the item that was right-clicked, or null if the click was on the chart background.
    * @param x The x location of the right-click in view coordinates.
    * @param y The y location of the right-click in view coordinates.
    * @param sub The sub-widget, or null if over the main part of the item.*/
    bind(name: 'contextmenu', handler: (id?: string, x?: number, y?: number, sub?: string) => void): void;
        
    /** The dblclick event is triggered when the end-user double-clicks on the chart surface. On touch devices this is triggered when the end-user double-taps the chart. Default action: Zoom in (animated) when double-clicking the background; open or close a combo. Return true to override this behaviour.
    * @param id The id of the item that was double-clicked, or null if the mouse was on the chart background.
    * @param x The x location of the double-click in view coordinates.
    * @param y The y location of the double-click in view coordinates.
    * @param sub The sub-widget clicked, or null if the click is over the main part of the item.*/
    bind(name: 'dblclick', handler: (id?: string, x?: number, y?: number, sub?: string) => boolean): void;
        
    /** The delete event is triggered when the user presses the delete key on the keyboard. The backspace key is not supported. Default behaviour: remove the item from the chart. Return true to override this behaviour.*/
    bind(name: 'delete', handler: () => boolean): void;
        
    /** The dragcomplete event is fired after the default behaviour has been performed and everything is finished. Note that dragcomplete will still fire even if the default behaviour has been disabled.
    * @param type The type of the drag: 'move', 'hand', 'area', 'resize', 'offset' and 'dummy' are all various types of drag.
    * @param id The id of the item is being dragged, or null if no item is being dragged.
    * @param x The x location of the drag in view coordinates.
    * @param y The y location of the drag in view coordinates.*/
    bind(name: 'dragcomplete', handler: (type?: string, id?: string, x?: number, y?: number) => void): void;
        
    /** The dragend event is fired just before drags finish. This event is designed to allow you to customise the behaviour of the drag result. Default behaviour: finish the drag action. The precise behaviour depends on the nature of the drag.
    * @param type The type of the drag: 'move', 'hand', 'area', 'resize', 'offset' and 'dummy' are all various types of drag.
    * @param id The id of the item is being dragged, or null if no item is being dragged.
    * @param x The x location of the drag in view coordinates.
    * @param y The y location of the drag in view coordinates.*/
    bind(name: 'dragend', handler: (type?: string, id?: string, x?: number, y?: number) => boolean): void;
        
    /** The dragover event is fired by the 'move' drag when dragging over another item.
    * @param id The id of the item underneath the dragged item, or null if the drag is over the background.
    * @param x The x location of the drag in view coordinates.
    * @param y The y location of the drag in view coordinates.
    * @param sub The sub-widget hovered over, or null if the hover is over the main part of the item.*/
    bind(name: 'dragover', handler: (id?: string, x?: number, y?: number, sub?: string) => void): void;
        
    /** The dragstart event is fired at the beginning of a drag. Unless panning the map, returning true from your event handler will prevent the default drag action occurring. The 'move' and 'hand' draggers, when not in map mode, allow you to control the drag operation by returning an object with the following properties: x (boolean) - whether dragging is allowed in the x-direction. The default is true. y (boolean) - whether dragging is allowed in the y-direction. The default is true. The 'move' dragger objects also support these properties: add (array) - an array of ids of items that will also be dragged, even if they are not selected. combos (boolean) - whether dragging nodes in combos also drags the combos. The default is true.
    * @param type The type of the drag: 'move' or 'hand'
    * @param id The id of the item that is being dragged, or null if no item is being dragged.
    * @param x The x location of the drag in view coordinates.
    * @param y The y location of the drag in view coordinates.
    * @param sub The sub-widget dragged, or null if the drag is over the main part of the item.*/
    bind(name: 'dragstart', handler: (type?: 'hand' | 'move', id?: string, x?: number, y?: number, sub?: string) => DragControlOptions): void;
        
    /** The dragstart event is fired at the beginning of a drag. Return true from your event handler to prevent the default drag action occurring.
    * @param type The type of the drag: 'area', 'resize', 'offset', 'dummy' are all various types of drag.
    * @param id The id of the item that is being dragged, or null if no item is being dragged.
    * @param x The x location of the drag in view coordinates.
    * @param y The y location of the drag in view coordinates.
    * @param sub The sub-widget dragged, or null if the drag is over the main part of the item.*/
    bind(name: 'dragstart', handler: (type?: 'area' | 'resize' | 'offset' | 'dummy', id?: string, x?: number, y?: number, sub?: string) => boolean): void;
        
    /** The edit event is triggered when the user presses the F2 function button. It can be useful to listen to this if you would like to offer label edit functionality.*/
    bind(name: 'edit', handler: () => void): void;
        
    /** The error event is fired when an error occurs inside the handler of another event.
    * @param message The message.
    * @param error The error object thrown.*/
    bind(name: 'error', handler: (message?: string, error?: Error) => void): void;
        
    /** The hover event happens when the mouse hovers over an item for a second or when dragging an external element over the chart (e.g. HTML5 drag and drop).
    * @param id The id of the item the mouse is over, or null if the mouse is over the chart background.
    * @param x The x location of the mouse.
    * @param y The y location of the mouse.
    * @param sub The sub-widget hovered over, or null if the hover is over the main part of the item.*/
    bind(name: 'hover', handler: (id?: string, x?: number, y?: number, sub?: string) => void): void;
        
    /** The keydown event occurs as the end-user presses a key. Default action: various. Arrow keys move the selection, ctrl-A selects all, F2 raises edit event, and Del raises delete event. Return true to override this behaviour.
    * @param keyCode The keyCode of the key pressed.*/
    bind(name: 'keydown', handler: (keyCode?: number) => boolean): void;
        
    /** The map event is fired at the start and end of a map show or hide operation.
    * @param type The type of the event: 'showstart', 'showend', 'hidestart' or 'hideend'.*/
    bind(name: 'map', handler: (type?: string) => void): void;
        
    /** The mousedown event occurs as the end-user presses a mouse button. Default action: select/deselect items, depending on whether the mouse down occured on an item or the background, and whether the CTRL or SHIFT keys are pressed. Return true to override this behaviour.
    * @param id The id of the item under the mouse, or null if the mouse was on the chart background.
    * @param x The x location of the mouse cursor in view coordinates.
    * @param y The y location of the mouse cursor in view coordinates.
    * @param button The button used. 0 is logical left button, 1 is middle and 2 is logical right. 
    * @param sub The sub-widget, or null if the mouse is over the main part of the item.*/
    bind(name: 'mousedown', handler: (id?: string, x?: number, y?: number, button?: number, sub?: string) => boolean): void;
        
    /** The mousewheel event occurs as the end-user uses a mouse wheel or scrolls using a trackpad. Default action: zooms the chart in or out. Return true to override this behaviour.
    * @param delta Abstract value describing how far the wheel 'turned'. The sign indicates the direction of the movement.
    * @param x The x location of the mouse cursor in view coordinates.
    * @param y The y location of the mouse cursor in view coordinates.*/
    bind(name: 'mousewheel', handler: (delta?: number, x?: number, y?: number) => boolean): void;
        
    /** The overview event is triggered when the user clicks on the overview icon.
    * @param state The final state of the overview after the action completes - either 'open' or 'close'.*/
    bind(name: 'overview', handler: (state?: string) => void): void;
        
    /** The prechange event is triggered whenever the chart changes by either a user action, such as dragging items, or programmatically by calling API methods.
    * @param change The change that is happening - one of 'arrange', 'arrange combo', 'close', 'combine', 'delete', 'expand', 'hide', 'layout', 'merge', 'move', 'offset', 'open', 'properties', 'resize', 'transfer' or 'uncombine'.*/
    bind(name: 'prechange', handler: (change?: string) => void): void;
        
    /** The progress event is triggered during long running tasks such as layouts and centrality calculations.
    * @param task The task which is running, for example, 'layout' or 'betweenness'.
    * @param progress How near the task is to completion on a scale of 0 to 1, where 0 is just started and 1 is finished.<br >Note that a progress of 1 indicates that the layout has finished computing, but not that the nodes have finished repositioning themselves. Layouts report progress differently depending on the layout used: <ul><li> Standard - Reports incrementally </li><li> Organic - Only reports 0 or 1 </li><li> Hierarchy - Only reports 0 or 1 </li><li> Sequential - Only reports 0 or 1 </li><li> Lens - Reports incrementally </li><li> Radial - Only reports 0 or 1 </li><li> Structural - Reports incrementally </li><li> Tweak - Only reports 0 or 1 </li></ul>*/
    bind(name: 'progress', handler: (task?: string, progress?: number) => void): void;
        
    /** The selectionchange event is triggered immediately after the end-user changes the selection by clicking or touching the chart surface. */
    bind(name: 'selectionchange', handler: () => void): void;
        
    /** The touchdown is triggered on touch devices when the end-user touches the chart surface. Default action: select an item if under the touch. Return true to override this behaviour.
    * @param id The id of the item under the touch, or null if the touch was on the chart background.
    * @param x The x location of the touch in view coordinates.
    * @param y The y location of the touch in view coordinates.
    * @param sub The sub-widget touched, or null if the touch was over the main part of the item.*/
    bind(name: 'touchdown', handler: (id?: string, x?: number, y?: number, sub?: string) => boolean): void;
        
    /** The viewchange event is fired after any view settings, such as zoom or pan. This event is also fired when the view state is changed programmatically. Note that in map mode, viewchange is only fired at the end of a drag.*/
    bind(name: 'viewchange', handler: () => void): void;
  }
    
  interface TimeBar {
    /** Clear removes all data from the time bar.*/
    clear(): void;
        
    /** Destroys the current instance of the time bar, freeing any allocated resources.*/
    destroy(): void;
        
    /** The getIds function returns an array of the ids that have datetimes in the specified range.
    * @param dt1 The start of the required range of datetimes.
    * @param dt2 The end of the required range of datetimes.
    * @returns An array of the ids that have datetimes in the specified range.*/
    getIds(dt1: Date | number, dt2: Date | number): Array<string>;
        
    /** The inRange function determines whether the item has a datetime either within the time bar's time range, or which overlaps any part of a time period in the range. Note that the item must have been loaded into the time bar.
    * @param item The item or id to range test.
    * @returns Returns true if the specified item exists in the time bar and has a datetime that's either within the time range, or which overlaps any part of a time period, otherwise false.*/
    inRange(item: TimeBarItem | string): boolean;
        
    /** Replaces the time bar data with the new data specified.
    * @param data The data to load into the time bar    */
    load(data: TimeBarData): Promise<void>;
        
    /** The mark function sets the time bar marks.
    * @param dts Sets the mark list. 
    * @returns The current mark list.*/
    mark(dts?: Date | number | TimePeriod | Array<Date | number | TimePeriod>): Date | number | TimePeriod | Array<Date | number | TimePeriod>;
        
    /** The mark function gets the time bar marks.*/
    mark(): Date | number | TimePeriod | Array<Date | number | TimePeriod>;
        
    /** Inserts new data into the time bar, merging it with any existing time bar data.
    * @param items The KeyLines time bar data object or array of items to merge into the existing time bar data*/
    merge(items: TimeBarItem | TimeBarData): Promise<void>;
        
    /** The options function gets options for the time bar.*/
    options(): TimeBarOptions;
        
    /** The options function gets options for the time bar.
    * @param val The options function gets options for the time bar.
    * @returns A promise*/
    options(val: TimeBarOptions): Promise<void>;
        
    /** Pan the time bar in the direction specified.
    * @param direction Which direction to pan
    * @param options Options controlling the pan operation*/
    pan(direction?: "back" | "forward", options?: TimeBarPanOptions): Promise<void>;
        
    /** The pause function stops the continuous animation of the time bar range started by play().*/
    pause(): void;
        
    /** The play function starts a continuous animation of the time bar range.
    * @param options Options controlling the play operation.*/
    play(options?: TimeBarPlayOptions): void;
        
    /** The range function gets the time range of the time bar.*/
    range(): TimeBarRangeResult;
        
    /** The range function sets the time range of the time bar.
    * @param dt1 the new start time for the time range of the time bar
    * @param dt2 the new end time for the time range of the time bar
    * @param options Options controlling the operation*/
    range(dt1: Date | number, dt2: Date | number, options?: TimeBarRangeOptions): Promise<void>;
        
    /** Gets the time bar selection lines.*/
    selection(): Array<string>;
        
    /** Sets the time bar selection lines.
    * @param items An array of items to be selected in the time bar, or an object if just one selection is made.
    * @returns An array of the current selections.*/
    selection(items: SelectionOptions | Array<SelectionOptions>): Array<string>;
        
    /** Sets the location of the time bar on the page.  Set this to null to temporarily remove it.
    * @param element The id string or DOM element of the parent container that the time bar should append to.*/
    setContainer(element?: string | HTMLElement): void;
        
    /** The unbind function detaches an event handler that was attached to an event with bind.
    * @param name The name of the event to be detached from, e.g., 'click'. You can also unbind multiple events in a single call, separating each one with a comma or space, e.g. 'start, end'.
    * @param handler The event handler that was supplied to the bind call.*/
    unbind(name?: string, handler?: Function): void;
        
    /** Zoom the time bar in the manner specified.
    * @param how How to zoom the time bar: 'in', 'out', 'fit' (fit the time range to the data)    
    * @param options Options controlling the zoom operation*/
    zoom(how?: "in" | "out" | "fit", options?: TimeBarZoomOptions): Promise<void>;
  
    /** Binding to the all event will capture all events that occur within the KeyLines time bar. It is slightly different in structure to other events in that the first argument is the name of the event which was captured. The rest of the arguments depend on the type of event captured. Return true to override the event's default action
    * @param name The name of the event which was captured, e.g. 'click'.*/
    bind(name: 'all', handler: (name?: string) => boolean): void;
        
    /** The change event is fired when the time range of the time bar changes. To get the new range, use the range function. This event is also fired when the time range is changed programmatically, but not if the change happens as a result of loading data that's outside the current range.*/
    bind(name: 'change', handler: () => void): void;
        
    /** The click event happens when the mouse clicks on the time bar.
    * @param type The type of thing clicked on:<ul><li>'bar'</li><li>'selection'</li><li>'scale' - the time axis scale</li><li>'histo' - the histogram area between the sliders</li><li>'left' - the left slider</li><li>'right' - the right slider</li><li>'slider' - the areas outside the current slider range</li><li>'controlbar' - the control bar at the bottom of the time bar</li><li>'fit', 'previous', 'next', 'play', 'playextend', 'zoomin', 'zoomout' - control bar controls</li><li>null (if there is nothing under the mouse)</li>
    * @param index The index of the selection clicked on, or null for other click types.
    * @param value The value of either the bar or selection, or null for other click types.
    * @param x The centre of the bar or selection point.
    * @param y The height of the bar or selection point.
    * @param dt1 The date at the start of the clicked range.
    * @param dt2 The date at the end of the clicked range.*/
    bind(name: 'click', handler: (type?: string, index?: number, value?: number, x?: number, y?: number, dt1?: Date, dt2?: Date) => void): void;
        
    /** The contextmenu event happens when the user right-clicks on the time bar surface.
    * @param type The type of thing clicked on:<ul><li>'bar'</li><li>'selection'</li><li>'scale' - the time axis scale</li><li>'histo' - the histogram area between the sliders</li><li>'left' - the left slider</li><li>'right' - the right slider</li><li>'slider' - the areas outside the current slider range</li><li>'controlbar' - the control bar at the bottom of the time bar</li><li>'fit', 'previous', 'next', 'play', 'playextend', 'zoomin', 'zoomout' - control bar controls</li><li>null (if there is nothing under the mouse)</li>
    * @param index The index of the selection clicked on, or null for other click types.
    * @param value The value of either the bar or selection, or null for other click types.
    * @param x A suggested location for the tooltip in the x direction - the centre of the bar or selection point.
    * @param y A suggested location for the tooltip in the y direction - the height of the bar or selection point.
    * @param dt1 The date at the start of the clicked range.
    * @param dt2 The date at the end of the clicked range.*/
    bind(name: 'contextmenu', handler: (type?: string, index?: number, value?: number, x?: number, y?: number, dt1?: Date, dt2?: Date) => void): void;
        
    /** The dblclick event happens when the mouse double-clicks on the time bar. On touch devices this is triggered when the user double-taps the time bar. Default action: Zoom in (animated) when double-clicking anywhere except the control bar. Return true to override this behaviour.
    * @param type The type of thing clicked on:<ul><li>'bar'</li><li>'selection'</li><li>'scale' - the time axis scale</li><li>'histo' - the histogram area between the sliders</li><li>'left' - the left slider</li><li>'right' - the right slider</li><li>'slider' - the areas outside the current slider range</li><li>'controlbar' - the control bar at the bottom of the time bar</li><li>'fit', 'previous', 'next', 'play', 'playextend', 'zoomin', 'zoomout' - control bar controls</li><li>null (if there is nothing under the mouse)</li>
    * @param x The centre of the bar or selection point.
    * @param y The height of the bar or selection point.*/
    bind(name: 'dblclick', handler: (type?: string, x?: number, y?: number) => boolean): void;
        
    /** The dragcomplete event is fired after the default behaviour has been performed and everything is finished. Note that dragcomplete will still fire even if the default behaviour has been disabled.
    * @param type The type of the drag: 'hand', 'left' or 'right'.
    * @param x The x location of the drag.
    * @param y They y location of the drag.*/
    bind(name: 'dragcomplete', handler: (type?: string, x?: number, y?: number) => void): void;
        
    /** The dragend event is fired at the end of a drag. Return true to make the drag snap back to its original position. Default behaviour: finish the drag action. The precise behaviour depends on the nature of the drag. Return true from your event handler to prevent the default drag action occuring.
    * @param type The type of the drag: 'hand', 'left' or 'right'.
    * @param x The x location of the drag.
    * @param y They y location of the drag.*/
    bind(name: 'dragend', handler: (type?: string, x?: number, y?: number) => boolean): void;
        
    /** The dragstart event is fired at the beginning of a drag. Return true from your event handler to prevent the default drag action occuring.
    * @param type The type of the drag: 'hand', 'left' or 'right'.
    * @param x The x location of the drag.
    * @param y They y location of the drag.*/
    bind(name: 'dragstart', handler: (type?: string, x?: number, y?: number) => boolean): void;
        
    /** The end 'data' event is triggered when the right slider reaches the last data point; the end 'range' event is triggered when the left slider reaches the last data point.
    * @param type The type of end reached, either 'data' or 'range'.*/
    bind(name: 'end', handler: (type?: string) => void): void;
        
    /** The error event is fired when an error occurs inside the handler of another event.
    * @param message The message.
    * @param error The error object thrown.*/
    bind(name: 'error', handler: (message?: string, error?: Error) => void): void;
        
    /** The hover event happens when the mouse hovers over the time bar.
    * @param type  The type of thing clicked on:<ul><li>'bar'</li><li>'selection'</li><li>'scale' - the time axis scale</li><li>'histo' - the histogram area between the sliders</li><li>'left' - the left slider</li><li>'right' - the right slider</li><li>'slider' - the areas outside the current slider range</li><li>'controlbar' - the control bar at the bottom of the time bar</li><li>'fit', 'previous', 'next', 'play', 'playextend', 'zoomin', 'zoomout' - control bar controls</li><li>null (if there is nothing under the mouse)</li>
    * @param index The index of the selection touched on, or null for other touch types.
    * @param value The value of either the bar or selection, or null for other hover types.
    * @param x A suggested location for the tooltip in the x direction - the centre of the bar or selection point.
    * @param y A suggested location for the tooltip in the y direction - the height of the bar or selection point.
    * @param dt1 The date at the start of the hovered range.
    * @param dt2 The date at the end of the hovered range.*/
    bind(name: 'hover', handler: (type?: string, index?: number, value?: number, x?: number, y?: number, dt1?: Date, dt2?: Date) => void): void;
        
    /** The mousewheel event occurs as the end-user uses a mouse wheel or scrolls using a trackpad. Default action: zooms the time bar in or out. Return true to override this behaviour. Return true to override this behaviour.
    * @param delta Abstract value describing how far the wheel 'turned'. The sign indicates the direction of the movement.
    * @param x The x location of the mouse cursor.
    * @param y The y location of the mouse cursor.*/
    bind(name: 'mousewheel', handler: (delta?: number, x?: number, y?: number) => boolean): void;
        
    /** The pause event is triggered whenever the time bar stops playing by the user pressing the pause button or programmatically calling timebar.pause(). It is also called when the time bar stops playing when it reaches the end of the range.*/
    bind(name: 'pause', handler: () => void): void;
        
    /** The play event is triggered whenever the time bar starts to play.
    * @param type The type of play mode, either 'extend' or 'normal'.*/
    bind(name: 'play', handler: (type?: string) => void): void;
        
    /** The start 'data' event is triggered when the left slider reaches the first data point; the start 'range' event is triggered when the right slider reaches the first data point.
    * @param type The type of start reached, either 'data' or 'range'.*/
    bind(name: 'start', handler: (type?: string) => void): void;
        
    /** The touchdown event happens when the user touches the time bar on a touch enabled device.
    * @param type The type of thing touched on:<ul><li>'bar'</li><li>'selection'</li><li>'scale' - the time axis scale</li><li>'histo' - the histogram area between the sliders</li><li>'left' - the left slider</li><li>'right' - the right slider</li><li>'slider' - the areas outside the current slider range</li><li>'controlbar' - the control bar at the bottom of the time bar</li><li>'fit', 'previous', 'next', 'play', 'playextend', 'zoomin', 'zoomout' - control bar controls</li><li>null (if there is nothing under the mouse)</li>
    * @param index The index of the selection touched on, or null for other touch types.
    * @param value The value of either the bar or selection, or null for other touch types.
    * @param x The centre of the bar or selection point.
    * @param y The height of the bar or selection point.
    * @param dt1 The date at the start of the touched range.
    * @param dt2 The date at the end of the touched range.*/
    bind(name: 'touchdown', handler: (type?: string, index?: number, value?: number, x?: number, y?: number, dt1?: Date, dt2?: Date) => void): void;
  }
  
  interface Combo {
    /** Arrange the items within an open combo.
    * @param id The id or the array of ids of the combos to be arranged.
    * @param options Options controlling the arrange operation.
    * @returns A Promise.*/
    arrange(id: string | Array<string>, options?: ComboArrangeOptions): Promise<void>;
        
    /** Closes the specified open combo(s) so the items inside are no longer visible.
    * @param ids The id string or array of id strings of the combos to be closed.
    * @param options Options controlling the close operation.
    * @returns A Promise.*/
    close(ids: string | Array<string>, options?: CloseOptions): Promise<void>;
        
    /** Combines the nodes specified into a single 'combo' node. Any links between the nodes are no longer displayed.
    * @param comboDefinition A definition of the combo to create, or an array of definitions.
    * @param options Options controlling the combine operation.
    * @returns A Promise.*/
    combine(comboDefinition: ComboDefinition | Array<ComboDefinition>, options?: CombineOptions): Promise<Array<string>>;
        
    /** find(ids) Returns an array of combo ids that contains the given items.
    * @param ids The ids of the items to be looked up.
    * @param options Options controlling how the find operates.
    * @returns The ids of the combos containing the given items, or null if not found.*/
    find(ids: Array<string>, options?: ComboFindOptions): Array<string>;
        
    /** find(id) Returns the string id of the combo containing the given item.
    * @param id The id of the item to be looked up.
    * @param options Options controlling how the find operates.
    * @returns The id of the combo containing the given items, or null if not found.*/
    find(id: string, options?: ComboFindOptions): string;
        
    /** Returns every underlying node and link inside a combo or nest of combos, or null if the id is not a combo.
    * @param id The id of the combo.
    * @returns An object in the form {links:[link1, link2, ..], nodes:[node1, node2, ..]}*/
    info(id: string): any;
        
    /** isCombo tests node or link ids to find out whether they are combo nodes or combo links.
    * @param id The id string or the array of id strings of the items to be tested.
    * @param options Options controlling whether links or nodes are tested.
    * @returns True if any node or link id are a combo, false otherwise.*/
    isCombo(id: string | Array<string>, options?: IsComboOptions): boolean;
        
    /** isOpen tests whether an item is an open combo.
    * @param id The id string of the item to be tested.
    * @returns True if the item id is an open combo, false otherwise.*/
    isOpen(id: string): boolean;
        
    /** Opens the specified combo(s) so the contents are visible inside a combo border on the chart.
    * @param ids The id string or array of id strings of the combos to be opened.
    * @param options Options controlling the open operation.
    * @returns A Promise.*/
    open(ids: string | Array<string>, options?: OpenOptions): Promise<void>;
        
    /** The reveal function sets the list of revealed links as an array of ids.
    * @param ids The id string, or array of id strings, of the links to be revealed.
    * @returns The currently revealed links as an array of id strings.*/
    reveal(ids?: string | Array<string>): Array<string>;
        
    /** The reveal function gets the list of revealed links as an array of ids.*/
    reveal(): Array<string>;
        
    /** Transfers the specified items into or out of a combo. Note: You must wait for the combine callback to be invoked before performing another chart function.
    * @param id The id string or array of id strings of nodes to be transferred into or out of a combo.
    * @param comboId The id of the combo to transfer the items to, or null to transfer items out of the combo and onto the chart.
    * @param options Options controlling the transfer operation.
    * @returns A Promise.*/
    transfer(id: string | Array<string>, comboId: string, options?: TransferOptions): Promise<void>;
        
    /** Uncombines the specified combo nodes and combo links: items inside the combo are displayed on the chart.
    * @param id The id or the array of ids of the combos to be uncombined.
    * @param options Options controlling the uncombine operation.
    * @returns A Promise.*/
    uncombine(id: string | Array<string>, options?: UncombineOptions): Promise<void>;
  }
  
  interface Map {
    /** Hide the map that was displayed with the show function. Chart nodes with lat and lng  properties are repositioned as specified by the 'transition'options setting. The speed of the transition depends on settings made with the options function.
    * @returns A Promise.*/
    hide(): Promise<void>;
        
    /** Use isShown to discover whether the map is currently shown.*/
    isShown(): boolean;
        
    /** Use leafletMap to get direct access to the underlying Leaflet map object that is used in map mode.*/
    leafletMap(): any;
        
    /** Use mapCoordinates to discover the exact latitude and longitude coordinates of a point given its view coordinates.
    * @param x The x position in view coordinates.
    * @param y The y position in view coordinates.
    * @returns An object {lat: lat, lng: lng} containing the map coordinates*/
    mapCoordinates(x: number, y: number): Location;
        
    /** The options function sets the options for the map.
    * @param val sets the map options
    * @returns The current options*/
    options(val: MapOptions): Promise<void>;
        
    /** The options function gets the options for the map.*/
    options(): MapOptions;
        
    /** Display a map behind the chart. Chart nodes with lat and lng properties are moved to the correct position on the map*/
    show(): Promise<void>;
        
    /** Use viewCoordinates to discover the exact position in view coordinates of a point given its latitude and longitude.
    * @param lat The latitude position of the point.
    * @param lng The longitude position of the point.
    * @returns An object {x: x, y: y} containing the view coordinates*/
    viewCoordinates(lat: number, lng: number): Coordinates;
  }
  
  interface Graph {
    /** The betweenness function calculates the betweenness centrality of all nodes in the graph.
    * @param options Various options which define if the graph is directed, the result normalized and values associated with the links
    * @returns A dictionary whose properties are the ids of the nodes in the graph. The values are the betweenness values. */
    betweenness(options?: BetweennessOptions): Promise<IdMap<number>>;
        
    /** Clear removes all items from the graph engine.*/
    clear(): void;
        
    /** The closeness function calculates the closeness centrality of all nodes in the graph.
    * @param options Various options which define if the graph is directed, the result normalized and values associated with the links   
    * @returns A dictionary whose properties are the ids of the nodes in the graph. The values are the closeness values. */
    closeness(options?: ClosenessOptions): Promise<IdMap<number>>;
        
    /** The clusters function groups nodes in the graph into a set of clusters, and then returns an array describing them.
    * @param options Options which control how the calculation is done.
    * @returns An array [cluster1, cluster2, ...] where cluster1, cluster2... are arrays containing ids of nodes that are all in the same cluster.*/
    clusters(options?: ClustersOptions): Array<Array<string>>;
        
    /** The components function returns the separate 'connected components' of the graph.
    * @param options Various options which define special rules for items iteration.
    * @returns An array of objects of the form {nodes:[id1, id2, ..], links:[id3, id4, ..]}, one entry for each component.*/
    components(options?: ComponentsOptions): Array<ComponentsResult>;
        
    /** The degrees function calculates the degrees (number of links) of all nodes in the graph.
    * @param options Various options which define the direction and values associated with the links
    * @returns An object whose properties are the ids of the nodes, the values of which are the degree values.*/
    degrees(options?: DegreesOptions): IdMap<number>;
        
    /** The distances function calculates the distances of all nodes from the node specified. The distance is the number of edges in a shortest path.
    * @param id The id of the node to start from.
    * @param options Various options for the direction and values associated with the paths   
    * @returns A dictionary object, the properties are the ids of the nodes, and the values are the distances.*/
    distances(id: string, options?: DistancesOptions): IdMap<number>;
        
    /** Call eigenCentrality to compute the eigenvector centrality of each node.
    * @param options Various options which define special rules for the eigenCentrality computation    
    * @returns An object in the form {id1: result1, id2: result2, ...} containing the eigenvector centrality of each node.*/
    eigenCentrality(options?: EigenCentralityOptions): IdMap<number>;
        
    /** The kCores function calculates subgraphs of the graph where each node has a degree at least k. It works by successively removing nodes of degree less than k until no further nodes can be removed.
    * @param options Various options which define special rules for items iteration.
    * @returns An object which describes the kCores found*/
    kCores(options?: KCoresOptions): KCoresResult;
        
    /** Replaces the graph data with the new data specified.
    * @param data The data to load into the graph engine*/
    load(data: ChartData): void;
        
    /** Call neighbours to find out which items are neighbours (are linked) to the id or ids passed in.
    * @param id The id string (or array of id strings) of the items whose neighbours should be found
    * @param options Various options which define special rules for items iteration.
    * @returns An object in the form {links:[id1, id2, ..], nodes:[id3, id4, ..]}*/
    neighbours(id?: string | Array<string>, options?: NeighboursOptions): NeighboursResult;
        
    /** Computes the PageRank of each node.
    * @param options Various options which define special rules for PageRank computation
    * @returns An object in the form {id1: result1, id2: result2, ...} containing the PageRank of each node.*/
    pageRank(options?: PageRankOptions): IdMap<number>;
        
    /** The shortestPaths function calculates all the shortest paths between the nodes specified.
    * @param id1 The id of the starting node on the path.
    * @param id2 The id of the ending node on the path.
    * @param options Various options for the direction and values associated with the paths
    * @returns An object which describes the path structure*/
    shortestPaths(id1?: string, id2?: string, options?: ShortestPathsOptions): ShortestPathsResult;
  }

  interface KeyLines {
    /** The components object has all the current components loaded by the KeyLines wrapper.*/
    components(): any;
        
    /** The coords function is a convenience function for discovering the coordinates of events relative to their target.
    * @param evt A DOM or jQuery event.
    * @returns An object whose properties 'x' and 'y' are the coordinates in 'target space'.*/
    coords(evt: Event): Coordinates;
        
    /** Creates a KeyLines Chart in your web page in the HTML element with the given id.
    * @deprecated
    * @param id The id of the HTML element to replace with the Chart.
    * @returns A promise with the created Chart.*/
    create(id?: string): Promise<Chart>;
        
    /** Creates a KeyLines Chart in your web page in the DOM element provided.
    * @deprecated
    * @param element The DOM element to replace with the Chart.
    * @returns A promise with the created Chart.*/
    create(element?: HTMLElement): Promise<Chart>;
        
    /** Creates a KeyLines component in your web page using an object defining the component.
    * @param component The definition object for the component.
    * @returns A promise with the created component.*/
    create(component: Component): Promise<Chart | TimeBar>;
        
    /** Creates KeyLines components in your web page using the objects supplied, defining the components.
    * @param components An array containing definition objects for the components.
    * @returns A promise with the created component.*/
    create(components: Array<Component>): Promise<Array<Chart | TimeBar>>;
        
    /** Use dashedLineSupport to discover whether the current browser can draw dashed lines. Deprecated.
    * @deprecated*/
    dashedLineSupport(): boolean;
        
    /** Use fullScreenCapable to discover whether the current browser can show elements full screen.*/
    fullScreenCapable(): boolean;
        
    /** The getFontIcon function is a helper to find the right character to use for the icon based on the class name.
    * @param classes A string containing the class names required to get the font icon.
    * @returns A number to select a font icon.*/
    getFontIcon(classes: string): number;
        
    /** The Graph engine can be used to perform traversals or other graph computations within a separate context from the chart.
    * @param options Options for the graph engine.
    * @returns A new instance of the graph engine used by KeyLines.*/
    getGraphEngine(options?: GraphEngineOptions): Graph;
        
    /** Return useful information about KeyLines including version number.*/
    info(): any;
        
    /** Mode defines which runtime KeyLines will use when calling KeyLines.create.
    * @param value The mode to use
    * @returns The current mode.*/
    mode(value: "auto" | "webgl" | "canvas"): string;
        
    /** The paths function tells KeyLines where it can find various resources on your server.
    * @param value An object specifying the path to the image resources.
    * @returns An object containing the current path settings.*/
    paths(value: PathsOptions): any;
        
    /** Use promisify to make the KeyLines API promise-aware.
    * @param Promise A valid Promise A/A+ constructor. By default, it'll use ES6 native promises if your browser supports it.*/
    promisify(Promise?: PromiseConstructor): void;
        
    /** setSize must be called when you change the size of the component.
    * @param id The id of the component element.
    * @param width The new width in pixels. Must be greater than 0.
    * @param height The new height in pixels. Must be greater than 0.*/
    setSize(id: string, width: number, height: number): void;
        
    /** setSize must be called when you change the size of the component.
    * @param element The HTMLElement of the component.
    * @param width The new width in pixels. Must be greater than 0.
    * @param height The new height in pixels. Must be greater than 0.*/
    setSize(element: HTMLElement, width: number, height: number): void;
        
    /** toggleFullScreen allows a given HTMLElement to be put in Full Screen mode, using the browser's full screen API.
    * @param element The element which should be made full screen. Cannot be null.
    * @param handler A function which will be called once the operation is complete.*/
    toggleFullScreen(element: HTMLElement, handler?: Function): void;
        
    /** Checks whether this device supports WebGL and meets the minimum requirements.*/
    webGLSupport(): boolean;
  }
}








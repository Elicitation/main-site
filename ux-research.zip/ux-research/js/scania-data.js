var data = {"type":"LinkChart","items":[{"type":"node","id":"1","t":"Fredrik Röjös","d":{"email":"fredrik.rojos@scania.se","expertise":["Desing Sprint", "Project Managment"]},  g: [
    {                          
    c: 'rgb(4, 30, 66)',         //the glyph fill colour
    p: 'ne',                     //glyph in NE corner
    t: 'i'                    //the glyph text
    }
  ]},{"type":"node","id":"2","t":"Anders Kuntsel","d":{"email":"anders.kuntsell@scania.se","expertise":"Project Managment"}},{"type":"node","id":"3","t":"Jesper Karlsson","d":{"email":"jesper.karlsson@scania.se","expertise":["Desing Sprint", "HTML"],"apa":6}},{"type":"node","id":"4","t":"Martin Leterius","d":{"email":"martin.leterius@gmail.com","expertise":["Javascript", "HTML"],"apa":189}}, {"id":"1-2","type":"link","id1":"1","id2":"2","d":{"count":233},"a2":true,"t":233},{"id":"3-4","type":"link","id1":"3","id2":"4", "d":{"count":200},"a2":true,"t":200},{"id":"4","type":"link","id1":"3","id2":"4","d":{"count":199},"a2":true,"t":199}, {"id":"3-4","type":"link","id1":"3","id2":"4", "d":{"count":200},"a2":true,"t":200},{"id":"3-1","type":"link","id1":"1","id2":"3","d":{"count":199},"a2":true,"t":199}]}